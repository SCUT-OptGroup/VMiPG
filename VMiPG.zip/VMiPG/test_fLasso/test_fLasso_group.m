
clear all;

restoredefaultpath;

addpath(genpath('prob_data'));

addpath(genpath('solvers_fLasso'));

addpath(genpath('functions'));

ntest = 1;

Fval_list1 = zeros(ntest,1); time_list1 = zeros(ntest,1); iter_list1 = zeros(ntest,1);
dnorm_list1 = zeros(ntest,1); xnz_list1 = zeros(ntest,1);  Bxnz_list1 = zeros(ntest,1);
relerr_list1 = zeros(ntest,1);

Fval_list2 = zeros(ntest,1); time_list2 = zeros(ntest,1); iter_list2 = zeros(ntest,1);
dnorm_list2 = zeros(ntest,1); xnz_list2 = zeros(ntest,1); Bxnz_list2 = zeros(ntest,1);
relerr_list2 = zeros(ntest,1);

Fval_list3 = zeros(ntest,1); time_list3 = zeros(ntest,1); iter_list3 = zeros(ntest,1);
dnorm_list3 = zeros(ntest,1); xnz_list3 = zeros(ntest,1);  Bxnz_list3 = zeros(ntest,1);
relerr_list3 = zeros(ntest,1);
m = 200;  n = 5000;

ncopy = 20;

gdim = floor(n/ncopy);  % the dimension of each group

errlist = [1,2,4,5];

lambdaw1 = [0.9,0.9,0.1,0.1,0.1,0.1,0.9,0.9,0.1,0.1,0.1,0.1,0.1];

lambdaw1 = [lambdaw1,0.9*ones(1,gdim-length(lambdaw1))]; %p/copy_times-length(x0) = 237

lambdaw1 = lambdaw1';

lambdaw = [];

for i =1:ncopy
    
    lambdaw = [lambdaw;lambdaw1];
    
end


Covtype = 2

errtype = errlist(1);

C = Cov_decom(m,n,Covtype);

for nt = 1:ntest
    
    %% *****************************************************************
    
    randstate = nt*100
    randn('state',double(randstate));
    rand('state',double(randstate));
    
    %% ****************** problem data ********************************
    
    [A,b,xs,supp_xs,supp_noise] = getData_snoise_group(m,n,ncopy,Covtype,errtype,randstate,C);
    
    [m,n] = size(A);
    
    [Bmap,BTmap] = FLBmap(n);
    
    Amap  = @(x) A*x;
    
    ATmap = @(x) A'*x;
    
    AATmap = @(x) Amap(ATmap(x));
    
    data.b = b;
    
    data.Amap = Amap;  data.ATmap = ATmap;
    
    data.Bmap = Bmap;  data.BTmap = BTmap;
    
    %% ***************** parameter setting  ***************************
    
    nu = 0.1;  model.nu = nu;
    
    Atb_inf = 1e-3*max(abs(ATmap(b))); %1e-3
    
    model.lambda = 1e-3*Atb_inf;%1e-3
    
    model.lambdaw = Atb_inf*lambdaw;
    
    x0 = ATmap(b);
    
    OPTIONS.printyes = 1;
    
    method_list = {'VMiPG-H','VMiPG-0bfgs','VMiLA-0bfgs'} ;
    
    for k = 1:3 %length(method_list)
        
        method = method_list{k};
        
        switch method
            
            case 'VMiPG-H'
                
                OPTIONS.maxiter = 10000;
                
                OPTIONS.maxiter_in = 100;
                
                OPTIONS.tol = 1e-5;
                
                tstart = clock;
                
                [xopt1,Fval1,dnorm1,iter1] = VMiPG_dADMM_fLasso(x0, data, OPTIONS, model);
                
                time_list1(nt)= etime(clock,tstart);
                
                xabs1 = abs(xopt1); max_xabs1 = max(xabs1);
                
                %xnz1 = length(xabs1(xabs1/max(1,max_xabs1)>1.0e-6));
                
                xnz1 = findnnz(xopt1,0.999);
                
                Bxnz1 = findnnz(data.Bmap(xopt1),0.999);
                
                Fval_list1(nt) = Fval1;  iter_list1(nt)=iter1;
                
                dnorm_list1(nt)= dnorm1; xnz_list1(nt) = xnz1; Bxnz_list1(nt) = Bxnz1;
                
                relerr_list1(nt) = norm(xopt1-xs)/norm(xs);
                
            case 'VMiPG-0bfgs'
                
                OPTIONS.maxiter = 30000;
                
                OPTIONS.maxiter_in = 1000;
                
                OPTIONS.tol = 1e-5;
                
                OPTIONS.metric_bfgs =1;
                
                tstart = clock;
                
                [xopt2,Fval2,dnorm2,iter2] = VMiPG_FISTA_fLasso(x0,data,OPTIONS,model);
                
                time_list2(nt)= etime(clock,tstart);
                
                xabs2 = abs(xopt2);  max_xabs2 = max(xabs2);
                
                %xnz2 = length(xabs2(xabs2/max(1,max_xabs2)>1.0e-6));
                
                xnz2 = findnnz(xopt2,0.999);
                
                Bxnz2 = findnnz(data.Bmap(xopt2),0.999);
                
                Fval_list2(nt) = Fval2;  iter_list2(nt)=iter2;
                
                dnorm_list2(nt)= dnorm2; xnz_list2(nt) = xnz2; Bxnz_list2(nt) = Bxnz2;
                
                relerr_list2(nt) = norm(xopt2-xs)/norm(xs);
                
            case 'VMiLA-0bfgs'
                
                OPTIONS.maxiter = 30000;
                
                OPTIONS.maxiter_in = 1000;
                
                OPTIONS.tol = 1e-5;
                
                OPTIONS.metric_bfgs = 1;
                
                tstart = clock;
                
                [xopt3,Fval3,dnorm3,iter3] = VMiLA_FISTA_fLasso(x0,data, OPTIONS, model);
                
                time_list3(nt)= etime(clock,tstart);
                
                xabs3 = abs(xopt3);  max_xabs3 = max(xabs3);
                
                % xnz3 = length(xabs3(xabs3/max(1,max_xabs3)>1.0e-6));
                
                xnz3 = findnnz(xopt3,0.999);
                
                Bxnz3 = findnnz(data.Bmap(xopt3),0.999);
                
                Fval_list3(nt) = Fval3;  iter_list3(nt)=iter3;
                
                dnorm_list3(nt)= dnorm3; xnz_list3(nt) = xnz3; Bxnz_list3(nt) = Bxnz3;
                
                relerr_list3(nt) = norm(xopt3-xs)/norm(xs);
        end
    end
end
fprintf('\n---------------------------------------------------------------------------\n');
fprintf('   Algorithm  |  iter  |    Obj.   |   Residual   |   CPU time  |   xnz   | Bxnz        |  relerr\n');
fprintf('---------------------------------------------------------------------------\n');
fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \t %4.3f \n', 'VMiPG-H', mean(iter_list1),mean(Fval_list1),mean(dnorm_list1), mean(time_list1), mean(xnz_list1),mean(Bxnz_list1),mean(relerr_list1));
fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \t %4.3f \n', 'VMiPG-S', mean(iter_list2),mean(Fval_list2),mean(dnorm_list2), mean(time_list2), mean(xnz_list2),mean(Bxnz_list2),mean(relerr_list2));
fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \t %4.3f \n', 'VMILA-S', mean(iter_list3),mean(Fval_list3),mean(dnorm_list3),mean(time_list3), mean(xnz_list3),mean(Bxnz_list3),mean(relerr_list3));

