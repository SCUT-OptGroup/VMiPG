%% ****************************************************************
%  filename: VMiLA_FISTA_fLasso
%% ***************************************************************
% Inexact variable metric line search method for l1-regularized regression problem.

% min{x} {f(x)+ g_1(x)+g_2(x)}

% where f is twice differentiable, g_1 and g_2 are proper lsc convex function.

%% the VMLS subproblem takes the following form

% min{x} {0.5*||Ax-b||^2+0.5mu*||x||^2 + g_1(x)+g_2(x)}

% we set g_1(x)= lambda ||omega .*x||_1 and  g_2(x)=||Bx||_1

%%
function [xopt,Fval,dnorm,iter,ttime,total_in,total_ls,Fval_list,time_list,Iter_list] = VMiLA_FISTA_fLasso(x,data,OPTIONS,model)

if isfield(OPTIONS,'tol');          tol          = OPTIONS.tol;           end
if isfield(OPTIONS,'tol2');          tol2          = OPTIONS.tol2;           end
if isfield(OPTIONS,'printyes');     printyes     = OPTIONS.printyes;      end
if isfield(OPTIONS,'maxiter');      maxiter      = OPTIONS.maxiter;       end
if isfield(OPTIONS,'maxiter_in');   maxiter_in   = OPTIONS.maxiter_in;    end
if isfield(OPTIONS,'metric');       metric      = OPTIONS.metric;        end
if isfield(OPTIONS,'metric_bfgs');  metric_bfgs  = OPTIONS.metric_bfgs;   end

lambda = model.lambda;

lambdaw = model.lambdaw;

nu = model.nu;

b = data.b;

n = length(x);


if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n VMiLA-0bfgs with fista');
    fprintf('\n *****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter  iter_in  ls       dnorm          Fval         time    dualgap');
end

%% parameters for FISTA

OPTIONS_FISTA.maxiter = maxiter_in;

OPTIONS_FISTA.printyes = 0;

OPTIONS_FISTA.metric_bfgs = metric_bfgs;

OPTIONS_FISTA.extra_con = 2.1;

%% ***************** Initialization part for VMLS ****************

delta = 3e-6;   beta = 0.1;

alpha = 1.5;  alpha_min = 1e-5;  alpha_max = 1e2;

tau_alpha = 0.5;  lm = 3;

Valpha = 1e30*ones(lm,1);


%% ********************* main loop ******************************
iter = 1;

total_in = 0;

total_ls = 0;

tstart = clock;

v1 = zeros(n,1);  v2 = v1;

Ax = data.Amap(x);

[fval,grad] = Loss_2block(Ax,b,data,nu);

gval = gfun_fLasso(x,data,lambda,lambdaw);

Fval = fval + gval;

Fval0 = abs(Fval);

Fval_list(iter) = Fval;

time_list(iter) = 0;

if metric_bfgs
    
    diffx = x;   diffg = grad;

    dot_xg = dot(diffx,diffg);

    sqnorm_diffg = norm(diffg)^2;

    tau2 = dot_xg/sqnorm_diffg;
    
    Hksnorm = tau2+(1/dot(diffx,diffg))*(2*norm(diffx-0.5*tau2*diffg)^2+0.5*tau2^2*norm(diffg)^2);
    
    info.diffx = x; info.diffg = grad;

else

    switch metric

        case 'I'

            dvec = ones(n,1);
    end

end
Iter_list = [];
while (iter<=maxiter)
    
    Valpha(1:lm-1) = Valpha(2:lm);
    
  %% **************** sole the subproblem with FISTA **************
   
    info.epsk = 1e+10/iter^2.1;  %% epsk = tauk in bonettini 20 
    
    info.gval = gval;
    
    if metric_bfgs
        
        inv_gradLip = 0.5/(Hksnorm*alpha);

        avec = x - alpha*(bfgsHx(grad,info.diffx,info.diffg));
        
        dvecx = bfgsBx(x,info.diffx,info.diffg);
        
        info.qks = (0.5/alpha)*dot(x,dvecx)-dot(grad,x);
        
        info.Ck = info.qks-info.gval;
        
        [y,v1,v2,resi_in,hfun,fista_iter] = FISTA_fLasso_VMILA(v1,v2,inv_gradLip,alpha,[],avec,data,OPTIONS_FISTA,info,lambda,lambdaw);

    else
        
        inv_gradLip = (0.5/alpha)*min(dvec);
        
        avec = x - alpha*(grad./dvec);
        
        info.qks = (0.5/alpha)*dot(x,x.*dvec)-dot(grad,x);

        info.Ck = info.qks-info.gval;
        
        [y,v1,v2,resi_in,hfun,fista_iter] = FISTA_fLasso_VMILA(v1,v2,inv_gradLip,alpha,dvec,avec,data,OPTIONS_FISTA,info,lambda,lambdaw);
        
    end      

    total_in = total_in+fista_iter;
 %========================================================================    
    Ay = data.Amap(y);
    
    fval_y = Loss_2block(Ay,b,data,nu);
    
    gval_y = gfun_fLasso(y,data,lambda,lambdaw);
    
    Fval_y = fval_y + gval_y;
    
    d = y - x;  Ad = Ay - Ax;
    
    dnorm = norm(d);
    
    if (dnorm < tol)
 
        xopt = x;
        
        return;
    end
    
 %% ********************* perform line-search *********************
    
    ls = 0;

    descent = -delta*hfun;
    
    xnew = y;  Axnew = Ay;  Fval_new = Fval_y;
    
    while (Fval_new > Fval - beta^(ls)*descent)
        
        ls = ls + 1;
        
        xnew = x + beta^(ls)*d;
        
        Axnew = Ax + beta^(ls)*Ad;
        
        fval_new = Loss_2block(Axnew,b,data,nu);
        
        gval_new = gfun_fLasso(xnew,data,lambda,lambdaw);
        
        Fval_new = fval_new + gval_new;
    end
    

    total_ls = total_ls+ls;
    %% ******************* Update iterate *************************
    
    if (Fval_y < Fval_new)||(ls==0)
        
        diffx = y - x;
        
        x = y;  Ax = Ay;
        
        gval = gval_y;  Fval = Fval_y;
    else
        
        diffx = xnew - x;
        
        x = xnew;  Ax = Axnew;
        
        gval = gval_new;  Fval = Fval_new;
    end
    
    ttime = etime(clock,tstart);
    
     if (printyes)%&&(mod(iter,10)==0)
        
        fprintf('\n %2d     %3d     %2d       %4.3e     %4.3f      %3.2f     %3.2e',iter,fista_iter,ls,dnorm,Fval,ttime,resi_in)
        
     end
    
     if(iter>10)&&(max(abs(Fval-Fval_list(iter-10:iter-1)))<=tol2*max(1,abs(Fval)))
        
        xopt = x;
        
        return; 
    end
        if ttime>=10000
            xopt=x;
        return
    end
    [~,gradnew] = Loss_2block(Ax,b,data,nu);
    
    diffg = gradnew - grad;
    
    grad = gradnew;
    
    %% ****************** update D and X *************************
    
    if metric_bfgs
        
        dot_xg = dot(diffx,diffg);
        
        normyk_sq = norm(diffg)^2;
    
        tau1 = norm(diffx)^2/dot_xg;
        
        tau2 = dot_xg/normyk_sq;
        
        if tau1<=1e+10 && tau2>=1e-10
 
            info.diffx = diffx; info.diffg = diffg;
                     
            Hksnorm = tau2+(1/dot_xg)*(2*norm(diffx-0.5*tau2*diffg)^2+0.5*tau2^2*normyk_sq);
        end
        
        diffx2 = bfgsBx(diffx,info.diffx,info.diffg); 
        
        diffg2 = bfgsHx(diffg,info.diffx,info.diffg);
        
    else
        
        diffx2 = diffx.*dvec; diffg2 = diffg./dvec;
        
    end
    
    bk_const = dot(diffx2,diffg);  ck_const = dot(diffg2,diffx);
    
    if (bk_const <= 0)
        
        alpha1 = 0.01*alpha_max;
        
    else
        
        alpha1BB = norm(diffx2)^2/bk_const;
        
        alpha1 = min(alpha_max, max(alpha_min, alpha1BB));
    end
    
    if (ck_const <= 0)
        
        alpha2 = 0.01*alpha_max;
        
    else
        
        alpha2BB = ck_const /norm(diffg2)^2;
        
        alpha2 = min(alpha_max, max(alpha_min, alpha2BB));
    end
    
    Valpha(lm) = alpha2;
    
    if (alpha2/alpha1 < tau_alpha)
        
        alpha = min(Valpha);
        
        tau_alpha = tau_alpha*0.9;
    else
        alpha = alpha1;
        
        tau_alpha = tau_alpha*1.1;
    end
        
    Fval_list(iter) = Fval;

    time_list(iter) = ttime;

    iter = iter + 1;
    
    %Iter_list = [Iter_list x];
end

xopt = x;

end

