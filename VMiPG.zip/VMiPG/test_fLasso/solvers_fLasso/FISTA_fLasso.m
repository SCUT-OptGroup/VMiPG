function [xbar,w1,w2,resi_in,iter] = FISTA_fLasso(x,tw1,tw2,gamma,alpha,dvec,avec,data,OPTIONS,info,lambda,lambdaw)

if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end
if isfield(OPTIONS,'extra_con');    extra_con   = OPTIONS.extra_con;     end
if isfield(OPTIONS,'metric_bfgs');  metric_bfgs  = OPTIONS.metric_bfgs;  end

xk = x;

%% ***************** initialization part ***************************

w1old = tw1;   w2old = tw2;

BTtw = tw1+tw2;    BTw = BTtw;

BTwold = BTw;

if metric_bfgs
    
    diffx = info.diffx; diffg = info.diffg;
    
    Gkak = (1/alpha)*bfgsBx(avec,diffx,diffg);
    
    y = avec - alpha*bfgsHx(BTtw,diffx,diffg);
else
    alp_dvec = alpha./dvec;
    
    y = avec - alp_dvec.*BTtw;
end

for iter = 1:maxiter
    
    w1 = tw1 + gamma*y;    %gamma = 1/Lip
    
    w2 = tw2 + gamma*y;
    
    %% ****************** proximal step *************************
    
    w1 = prox_g1star_fLasso(w1,lambda,gamma);
    
    w2 = Proj_box(w2,-lambdaw,lambdaw);
    
    BTw = w1+w2;
    
    %% **************** primal feasibility **************************
    
    if metric_bfgs
        
        tempw = avec - alpha*bfgsHx(BTw,diffx,diffg);
        
        dvecw =(1/alpha)*bfgsBx(tempw,diffx,diffg);
        
        dobj = 0.5*dot(tempw,dvecw);
        
        xbar = (w2+tempw)- Proj_box(w2+tempw,-lambdaw,lambdaw);
        
        gxbar = gfun_fLasso(xbar,data,lambda,lambdaw);
        
        dvec_xbar =(1/alpha)*bfgsBx(xbar,diffx,diffg);
        
        pobj = 0.5*dot(xbar,dvec_xbar)-dot(Gkak,xbar)+gxbar;
        
    else
        
        tempw = avec - alp_dvec.*BTw;
        
        dobj = (0.5/alpha)*dot(tempw,dvec.*tempw);
        
        xbar = (w2+tempw)- Proj_box(w2+tempw,-lambdaw,lambdaw);
        
        gxbar = gfun_fLasso(xbar,data,lambda,lambdaw);
        
        pobj = (1/alpha)*(0.5*dot(xbar,dvec.*xbar)-dot(dvec.*avec,xbar))+ gxbar;
    end
    
    resi_in = abs(pobj+dobj);
    
    if printyes
        
        fprintf('\n    %3g)  pobj %g dobj %g resi_in %g  gamma %g',iter,pobj,dobj,resi_in,gamma);
        
    end
        Thetak = pobj+info.qks;

    %epsk = info.epsk * min(abs(Thetak),1e+10);
    epsk = info.epsk;
    
    if (Thetak<info.gval)&&(resi_in<=epsk*norm(xbar-xk)^2)
        
        return;
    end
   %% ******************* extrapolation step *********************
    
    beta = (iter-1)/(iter+extra_con);
    
    tw1 = w1 + beta*(w1-w1old);
    
    tw2 = w2 + beta*(w2-w2old);
    
    w1old = w1; w2old = w2;
    
    BTtw  = BTw + beta*(BTw-BTwold);
    
    BTwold = BTw;  
    
    if metric_bfgs
        
        y = avec - alpha*bfgsHx(BTtw,diffx,diffg);
        
    else
        y = avec - alp_dvec.*BTtw;
    end
    
end
