%% ***************************************************************
%  To compute the function and gradient values of Phi_j  
%
%% ***************************************************************

function [proxu,uproxu,fval] = fgrad_SNCG(xi,u,sigma,mu,lambdaw)

[proxu,uproxu,Mwg2star] = prox_wg2star_fLasso(u,lambdaw,mu,1/sigma);

fval = 0.5*norm(xi)^2 + Mwg2star;  

end