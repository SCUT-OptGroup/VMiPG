%% ***************************************************************
% The conjugate_gradient method for the system of linear equations
% 
%        Ax = b    with Ax = x + gamma*AmapJ(V*AtmapJ(x))
%
% x0�� the starting point
% 
% res��the residual of Ax = b at x0, i.e., res = b- A(x0) 
%% ***************************************************************
function [x,Atx,iter,solve_ok] = cg_SNCG(Amap,ATmap,nzind,b,sigmu,res,tol,maxit,n)

m = size(b,1); resnrm =zeros(maxit,1);

if ~exist('tol','var'); tol=1e-2*norm(b); end

if ~exist('maxit','var'); maxit = 10; end

solve_ok = 1;

tiny = 1.0e-16;

stagnate_check = maxit;

d = zeros(m,1);

Ad = zeros(m,1);  Atd = zeros(n,1);

%% *************** Initialization part **************************

x = zeros(m,1);  Atx = Atd;   % such a starting point is crucial !!!

r = res;   z = r;  err = norm(r);

rho_old = err^2;  tau_old = err;

theta_old = 0;

%% ******************* Main Loop ********************************

for iter = 1:maxit
    
    Atz = ATmap(z);
    
    [Az,sigma] = Jac_SNCG(Amap,nzind,z,Atz,sigmu);
    
    if (abs(sigma)<tiny)   %% in this case z=0 since A is positive definite
        
        solve_ok = -1;
        
        break;
    else
        
        alfa = rho_old/sigma;
        
        r = r - alfa*Az;
        
    end
    
    norm_r = norm(r);
    
    theta = norm_r/tau_old;
    
    const = 1+theta^2;
  
    tau = tau_old*theta/sqrt(const);
   
    gam = theta_old^2/const;
    
    eta = alfa/const;
    
    d =  gam*d + eta*z;
    
    x = x + d;
    
    %%--------------------- stopping conditions  ---------------------------
    
    Ad = gam*Ad + eta*Az;
    
    Atd = gam*Atd + eta*Atz;
    
    Atx = Atx + Atd;
    
    res = res - Ad;
    
    err = norm(res);
    
    if (err < tol)

        return;
    end
    
    if (iter > stagnate_check) && (iter > 10)
        
        ratio = resnrm(iter-9:iter+1)./resnrm(iter-10:iter);
        
        if (min(ratio)>0.997) && (max(ratio)<1.003)
            
            solve_ok = -1;
            
            return;
        end
    end
    %%-----------------------------------------------------------------------
    rho = norm_r^2;
    
    beta = rho/rho_old;
    
    z = r + beta*z;
    
    rho_old = rho;
    
    tau_old = tau;
    
    theta_old = theta;
    
end

if (iter == maxit); solve_ok = -2; end

end

%%%%%%%%%%%%%%%%%%%%%% End of conjugate_gradient.m  %%%%%%%%%%%%%%%%%%%%%%% 