%% ***************************************************************
%  Given vector d, calculate 
%
%  Ad = d + sigma_mu*Anz(Anzt(d))
%  
%  sigma = <d,Ad> = ||d||^2 + sigma_mu*||Anzt(d)||^2
%
%% **************************************************************

function [Ad,sigma] = Jac_SNCG(Amap,nzind,d,Atd,sigma_mu)

Anztd = Atd.*nzind;

Ad = d + sigma_mu*Amap(Anztd);

sigma = norm(d)^2 + sigma_mu*norm(Anztd)^2;

end

