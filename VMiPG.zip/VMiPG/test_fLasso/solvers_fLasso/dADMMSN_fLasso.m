%% *************************************************************************
% filename: dADMMSN_fLasso
%% **************************************************************************
%%
%% The dual ADMM armed with semismooth Newton for solving the subproblem
%
%  min_{x,z}{0.5*||Ax||^2 -<b,x>+ g_1(x)+ g_2(x)
%
%%  whose dual problem is
%
%  min_{xi,zeta,eta}{0.5*||xi||^2 + g_1star(zeta) + wg_2star(eta)}
%  s.t. b-Amap(xi)-eta-zeta = 0
%
%% where g_1star and wg_2star are respectively the conjugate of g_1 and wg_2
%% ***************************************************************

%% ***************************************************************
%%
function [xvar,xi,zeta,sigma,resi_in,iter,ttime]= dADMMSN_fLasso(xi,Atxi,zeta,x,OPTIONS,Amap,ATmap,b,mu,info,data,lambda,lambdaw)
%%
if isfield(OPTIONS,'maxiter');        maxiter    = OPTIONS.maxiter;    end
if isfield(OPTIONS,'printyes');       printyes   = OPTIONS.printyes;   end
if isfield(OPTIONS,'sigma');          sigma      = OPTIONS.sigma;      end
if isfield(OPTIONS,'sigma_flag');     sigma_flag = OPTIONS.sigma_flag; end
if isfield(OPTIONS,'normb');          normb      = OPTIONS.normb;      end

tau = 1.618;

if (sigma_flag)

    sigma_scale = 1.2;

    sigma_max = 1e4;

    sigma_min = 1e-4;

    prim_win = 0;  dual_win = 0;

end


xk = x;

%%
if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n ************* ADMM for the iVMLS subproblem **************');
    fprintf('\n ****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter   SNit      pinf         dinf      ratio        sigma     time   relgap');
end
%% ********** parameters for the semismooth newton method ************

OPTIONS_SNDir.printyes = 0;

OPTIONS_SNDir.maxiter = 10;

OPTIONS_SNDir.tol = 1e-5; %min(1e-3*epsk,1e+2);  % is faster than 1e-5

OPTIONS_SNDir.normb = normb;

%%
%% ***********************  Main Loop ***************************

tstart = clock;

for iter = 1:maxiter

    %% *************** Compute xi and eta *************************

    tau_sig = tau*sigma;

    [xi,Atxi,eta,tempu,SNit] = SNCG_dADMM(xi,Atxi,Amap,ATmap,b,OPTIONS_SNDir,lambdaw,sigma,mu,x,zeta);

    %% ********************* compute zeta ***************************

    zeta = prox_g1star_fLasso(zeta+tempu,lambda,1/sigma);

    %% ********************** update x ***************************

    xold = x;

    x = xold + tau_sig*(b-Atxi-eta-zeta);

    %%
    pinf = norm(x-xold)/(tau_sig*(1+normb));

    prox_wg2 = prox_wg2star_fLasso(x+eta,lambdaw,mu,1);

    dinf1 = norm(xi-Amap(x))^2+norm(eta-prox_wg2)^2;

    dinf = sqrt(dinf1+norm(zeta-prox_g1star_fLasso(zeta+x,lambda,1))^2)/(1+normb);

    ratio = pinf/dinf;

    %% ************* checking optimality condition *******************


    %xvar = Prox_WL1(eta/mu,lambdaw/mu);
    
    xvar = x;

    pobj = 0.5*norm(Amap(xvar))^2 - b'*xvar + 0.5*mu*norm(xvar)^2+gfun_fLasso(xvar,data,lambda,lambdaw);

    eta = b - Atxi - zeta;

    dobjtemp = Prox_WL1(eta/mu,lambdaw/mu);

    dobj = 0.5*norm(xi)^2 +(0.5/mu)*norm(eta)^2 -(0.5*mu*norm(dobjtemp-eta/mu)^2+norm(lambdaw.*dobjtemp,1));

    resi_in = abs(dobj+pobj);

    ttime = etime(clock,tstart);

    if printyes

        fprintf('\n %3d    %2d       %6.5e        %6.5e    %3.2e     %3.2e    %3.2f   %3.2f     %3.2e',iter,SNit,pobj,dobj,pinf,dinf,sigma,ttime,resi_in);

    end

    pinf_temp = pinf*(tau_sig*(1+normb));

    %tempdnorm = norm(xvar-xk);

    %epsktemp = min(tempdnorm,tempdnorm^2);

	    Thetak = pobj+info.qks;

    %epsk = info.epsk * min(abs(Thetak),1e+10);
    epsk = info.epsk;

    if (Thetak<=info.gval)&&(resi_in<=epsk*norm(xvar-xk)^2)%&&(pinf_temp <=epsk*norm(xvar-xk)^2)

        return;
    end

    %% ****************** to update the value of sigma ****************

    if (sigma_flag)

        sigma_update_iter = sigma_fun(iter);

        if (ratio<1)

            prim_win = prim_win+1;

        elseif (ratio>1)

            dual_win = dual_win+1;

        end

        if (rem(iter,sigma_update_iter)==0)

            if (iter<=3000)

                if (prim_win>max(1,1.2*dual_win))

                    prim_win = 0;

                    sigma = max(sigma_min,sigma/sigma_scale);

                elseif (dual_win>max(1,1.2*prim_win))

                    dual_win = 0;

                    sigma = min(sigma_max,sigma*sigma_scale);

                end
            end
        end
    end

end
end

function sigma_update_iter = sigma_fun(iter)
if (iter<20)
    sigma_update_iter = 3;
elseif (iter < 120)
    sigma_update_iter = 5;
elseif (iter < 250)
    sigma_update_iter = 10;
elseif (iter < 500)
    sigma_update_iter = 50;
else
    sigma_update_iter = 100;
end
end