function [xbar,w1,w2,resi_in,hfun,iter] = FISTA_fLasso_VMILA(tw1,tw2,gamma,alpha,dvec,avec,data,OPTIONS,info,lambda,lambdaw)

if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end
if isfield(OPTIONS,'extra_con');    extra_con   = OPTIONS.extra_con;     end
if isfield(OPTIONS,'metric_bfgs');  metric_bfgs  = OPTIONS.metric_bfgs;  end

Ck = info.Ck;

%% ***************** initialization part ***************************

w1old = tw1;   w2old = tw2;

BTtw = tw1+tw2;    BTw = BTtw;

if metric_bfgs
    
    diffx = info.diffx; diffg = info.diffg;
    
    Gkak =(1/alpha)*bfgsBx(avec,diffx,diffg);
    
    y = avec - alpha*bfgsHx(BTtw,diffx,diffg);
else
    alp_dvec = alpha./dvec;
    
    y = avec - alp_dvec.*BTtw;
end

for iter = 1:maxiter
    
    w1 = tw1 + gamma*y;    %gamma = 1/Lip
    
    w2 = tw2 + gamma*y;
    
    %% proximal step
    
    w1 = prox_g1star_fLasso(w1,lambda,gamma);
    
    w2 = Proj_box(w2,-lambdaw,lambdaw);
    
    BTwold = BTw;  BTw = w1+w2;
    
    %% **************** primal feasibility **************************
    
    if metric_bfgs
        
        tempw = avec - alpha*bfgsHx(BTw,diffx,diffg); 
        
        dvecw = (1/alpha)*bfgsBx(tempw,diffx,diffg);
        
        dobj = 0.5*dot(tempw,dvecw);

        xbar = (w2+tempw)- Proj_box(w2+tempw,-lambdaw,lambdaw);
        
        gxbar = gfun_fLasso(xbar,data,lambda,lambdaw);
        
        dvec_xvar = (1/alpha)*bfgsBx(xbar,diffx,diffg);
          
        pobj = 0.5*dot(xbar,dvec_xvar)-dot(Gkak,xbar)+ gxbar;
        
    else
        tempw = avec - alp_dvec.*BTw;
        
        dobj = (0.5/alpha)*dot(tempw,dvec.*tempw);
        
        xbar = (w2+tempw)- Proj_box(w2+tempw,-lambdaw,lambdaw);
        
        gxbar = gfun_fLasso(xbar,data,lambda,lambdaw);
                
        pobj = (1/alpha)*(0.5*dot(xbar,dvec.*xbar)-dot(dvec.*avec,xbar))+ gxbar;
    end
    
    resi_in = abs(pobj+dobj);
    
    if printyes
        
        fprintf('\n    %3g)  hsigmaplus %g psi %g dual gap %g',iter,pobj,dobj,resi_in);
        
    end
    
    hfun = pobj+Ck;

    if (pobj+info.qks<info.gval)&&(hfun<=(-dobj+Ck)/(1+info.epsk))

        return;   
        
    end
    
    %% ******************* extrapolation step *********************
    
    beta = (iter -1)/(iter + extra_con);
    
    tw1 = w1 + beta*(w1-w1old);
    
    tw2 = w2 + beta*(w2-w2old);
    
    w1old = w1; w2old = w2;
    
    BTtw  = BTw + beta*(BTw - BTwold);
    
    if metric_bfgs
        
        y = avec - alpha*bfgsHx(BTtw,diffx,diffg);
    else
        y  = avec - alp_dvec.*BTtw;
    end
end
