%% ******** Semismooth Newton Method for solving the system ********
%
%    nabla Psi_k(xi)=0
%
%% ***************************************************************
%% Copyright by Shaohua Pan and Ruyu Liu (2022.4.14)

function [xi,Atxi,proxu,tempu,iter,norm_res]= SNCG_dADMM(xi,Atxi,Amap,ATmap,b,OPTIONS,lambdaw,sigma,mu,x,zeta)

%% ******************* Initialization of parameter *********************

if isfield(OPTIONS,'tol');             tolSN      = OPTIONS.tol;         end
if isfield(OPTIONS,'printyes');        printyes   = OPTIONS.printyes;    end
if isfield(OPTIONS,'maxiter');         maxiter    = OPTIONS.maxiter;     end
if isfield(OPTIONS,'normb');           normb      = OPTIONS.normb;       end

sigma_mu = sigma/(1+mu*sigma);

cg_tol = min(1e-2,100*tolSN);

cg_max = 20;

if  (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n \t   Semismooth Newton method for solving the problem of min phik(xi)');
    fprintf('\n ****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter cg_iter   lstep     grad_res         obj     time');
end

%% *************** the parameters for line search ***************

lsopts.c1 = 1e-4;

lsopts.c2 = 0.9;

lsopts.stepop = 1;

lsopts.printyes = 0;

dimx = size(x,1);

%% ******************** Main Loop *******************************

xsigma = x/sigma;

bzeta_xsig = b - zeta + xsigma;

u = bzeta_xsig-Atxi;

[proxu,uproxu,fval] = fgrad_SNCG(xi,u,sigma,mu,lambdaw);

gradPsi = xi - sigma*Amap(uproxu);

nzind = abs(u)>lambdaw;

if abs(fval)>1.0e+5
    
    ls_tol = 1e-4;
    
elseif abs(fval)>1.0e+2
    
    ls_tol = 1e-5;
else
    ls_tol = 1e-6;
end

res = -gradPsi;

norm_res = norm(res);

for iter = 1:maxiter
    
    if (norm_res<=tolSN)
        
        tempu = bzeta_xsig-Atxi-proxu;
        
        return;
    end       
        
    cg_tol = min(cg_tol,norm_res^(1.2));

    %% ******************* to calculate Newton direction **********************
    
    [dir,Atdir,cg_iter] = cg_SNCG(Amap,ATmap,nzind,res,sigma_mu,res,cg_tol,cg_max,dimx);

    [xi,Atxi,proxu,nzind,fval,gradPsi,lstep]=Lswolfe_dADMM(xi,Atxi,fval,gradPsi,dir,Atdir,Amap,bzeta_xsig,sigma,mu,lambdaw,lsopts,ls_tol);
    
    res = -gradPsi;
    
    norm_res = norm(res);
    
    if (printyes)        
        fprintf('\n %3.0d      %3.0d      %3.2e     %3.2e    %5.4e   %3.2e  %3.2e',iter,cg_iter,lstep,norm_res,fval,sigma,cg_tol);
    end   
    
end

tempu = bzeta_xsig-Atxi-proxu;

