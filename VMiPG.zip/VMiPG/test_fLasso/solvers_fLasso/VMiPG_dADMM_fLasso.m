%% ***************************************************************
%  filename: VMiPG_dADMM_fLasso
%% ***************************************************************
%% to solve the following composite optimization problem
%
%  min_{x}{theta(Ax-b)+ g_1(x)+g_2(x)}
%
%  Each step is to seek an inexact minimizer yk of the strongly convex program
%
%  min_{x} {0.5*||Ak(x)||^2-<bk,x>+g_1(x)+wg_2(x)}
%
%% ***************************************************************

function [xopt,Fval,dnorm,iter,ttime] = VMiPG_dADMM_fLasso(x,data,OPTIONS,model)

if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'maxiter_in');   maxiter_in  = OPTIONS.maxiter_in;    end
if isfield(OPTIONS,'tol');          tol         = OPTIONS.tol;           end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end

lambda = model.lambda;

lambdaw = model.lambdaw;

nu = model.nu;

b = data.b;

m = size(b,1);

n = length(x);

mu = 1e-5;  

delta = min(1,mu)/2;  beta = 0.1; 

if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    %   fprintf('\n \t IRPNM for solving l1-regularization %s regression with %s innersolver',model.loss,OPTIONS.solver);
    fprintf('\n *****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter   subit  ls       dnorm             Fval         time        sigma      gap');
end

%% **************** Initialization part for dADMM ***************

OPTIONS_ADMM.maxiter = maxiter_in;

OPTIONS_ADMM.printyes = 0;

OPTIONS_ADMM.sigma = 0.1;   % is better than 1 and 10

OPTIONS_ADMM.sigma_flag = 1;

xi = zeros(m,1);   zeta = zeros(n,1);

%% ********************* Main Loop ********************************

iter = 1;

total_in = 0;

tstart = clock;

Ax = data.Amap(x);

[fval,grad,Dx] = Loss_2block(Ax,b,data,nu);

gval = gfun_fLasso(x,data,lambda,lambdaw);

Fval = fval + gval;

Fval0 = abs(Fval);

while (iter<=maxiter)
        
    % Compute Lambda and mu at x where the hessian of f is A'*diag(Dx)*A
   
    Lambda = -min(0,Dx);
        
 %% *************** sole the subproblem with iVMLS ***************
  
    Dxp = Dx + Lambda ;
    
    adax = data.ATmap(Dxp.*Ax);
    
    sqrtDxp = Dxp.^(1/2);
    
    binput = adax + mu*x - grad;
    
    OPTIONS_ADMM.normb = norm(binput);
    
    info.epsk = Fval0/iter^(1.5);
    
    info.qks = 0.5*(dot(x,adax)+mu*norm(x)^2)-dot(grad,x);
    
    info.gval = gval;    
          
    Amap = @(x) sqrtDxp.*data.Amap(x);
    
    ATmap = @(x) data.ATmap(sqrtDxp.*x);
     
    [y,xi,zeta,sigma,resi_in,admm_it] = dADMMSN_fLasso(xi,ATmap(xi),zeta,x,OPTIONS_ADMM,Amap,ATmap,binput,mu,info,data,lambda,lambdaw);
        
    OPTIONS_ADMM.sigma = sigma;
    
    total_in = total_in + admm_it;
    
  %===============================================================================================
    
    Ay = data.Amap(y);
    
    fval_y = Loss_2block(Ay,b,data,nu);
    
    gval_y = gfun_fLasso(y,data,lambda,lambdaw);
    
    Fval_y = fval_y + gval_y;
    
    d = y - x;  Ad = Ay - Ax;
    
    dnorm = norm(d);
    
    if (dnorm < tol)        
        xopt = x;        
        return;
    end
    
    %% ********************* perform line search *********************
    
    ls = 0;
    
    descent = delta*dnorm^2;
    
    xnew = y;  Axnew = Ay;  Fval_new = Fval_y;
    
    while (Fval_new > Fval - beta^(ls)*descent)
        
        ls = ls + 1;
        
        xnew = x + beta^(ls)*d;
        
        Axnew = Ax+beta^(ls)*Ad;
        
        fval_new = Loss_2block(Axnew,b,data,nu);
        
        gval_new = gfun_fLasso(xnew,data,lambda,lambdaw);
        
        Fval_new = fval_new + gval_new;
    end
    
    %% ******************* Update iterate **************************
    
    if (Fval_y < Fval_new)||(ls==0)
        
        x = y;  Ax = Ay;
        
        gval = gval_y;  Fval = Fval_y;
        
    else
        
        x = xnew; Ax = Axnew;
        
        gval = gval_new;  Fval = Fval_new;
    end
    
    ttime = etime(clock,tstart);
    
     if (printyes) 
        fprintf('\n %2d     %2d     %2d        %4.3e        %5.3f       %3.1f       %3.2e    %3.2e',iter,admm_it,ls,dnorm,Fval,ttime,sigma,resi_in)
     end
    
     if(iter>10)&&(max(abs(Fval-Fval_list(iter-10:iter-1)))<=1.0e-4*max(1,Fval))
        
        xopt = x;
        
        return;
    end
    
    [fval,grad,Dx] = Loss_2block(Ax,b,data,nu);
    
    Fval_list(iter) = Fval;
    
    time_list(iter) = ttime;
      
    iter = iter + 1;
end

xopt = x;
end

