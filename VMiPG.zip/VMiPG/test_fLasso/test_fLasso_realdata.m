
clear all;

restoredefaultpath;

addpath(genpath('prob_data'));

addpath(genpath('solvers_fLasso'));

addpath(genpath('functions'));


Fval_list1 = zeros(ntest,1); time_list1 = zeros(ntest,1); iter_list1 = zeros(ntest,1);
dnorm_list1 = zeros(ntest,1); xnz_list1 = zeros(ntest,1);  Bxnz_list1 = zeros(ntest,1);

Fval_list2 = zeros(ntest,1); time_list2 = zeros(ntest,1); iter_list2 = zeros(ntest,1);
dnorm_list2 = zeros(ntest,1); xnz_list2 = zeros(ntest,1); Bxnz_list2 = zeros(ntest,1);

Fval_list3 = zeros(ntest,1); time_list3 = zeros(ntest,1); iter_list3 = zeros(ntest,1);
dnorm_list3 = zeros(ntest,1); xnz_list3 = zeros(ntest,1);  Bxnz_list3 = zeros(ntest,1);
data_name = {'E2006.train.mat','E2006.test.mat','pyrim_scale_expanded5.mat','bodyfat_scale_expanded7.mat','mpg_scale_expanded7.mat','triazines_scale_expanded4.mat','housing_scale_expanded7.mat'};
alpha1_list = [1e-4,1e-5,50,1e-2,1e-4,100,1e-2];
alpha2_list = [1e-3,1e-1,1e-3,1e-1,1e-1,1e-3,1e-1];
%alpha2_list = [1e-4,1e-4,1e-4,1e-2,1e-2,1e-4,1e-2];
for ii = 5
    dataset = data_name{ii}
    a1 = alpha1_list(ii)
    a2 = alpha2_list(ii)
    
    
    %% *****************************************************************
    
    randstate = 100;
    randn('state',double(randstate));
    rand('state',double(randstate));
    
    %% ******************daih  problem data ********************************
    load(dataset);
    [m,n] = size(A);
    
    [Bmap,BTmap] = FLBmap(n);
    
    Amap  = @(x) A*x;
    
    ATmap = @(x) A'*x;
    
    AATmap = @(x) Amap(ATmap(x));
    
    data.b = b;
    
    data.Amap = Amap;  data.ATmap = ATmap;
    
    data.Bmap = Bmap;  data.BTmap = BTmap;
    
    %% ***************** parameter setting  ***************************
    
    nu = 0.5;  model.nu = nu;
    
    Atb_inf = a1*max(abs(ATmap(b)));
    
    model.lambda = a2*Atb_inf;
    
    model.lambdaw = Atb_inf*rand(n,1);
    
    x0 = ATmap(b);
    
    OPTIONS.printyes = 1;
    
    method_list = {'VMiPG-H','VMiPG-0bfgs','VMiLA-0bfgs'} ;
    
    for k = 1:3  %length(method_list)
        
        method = method_list{k};
        
        switch method
            
            case 'VMiPG-H'
                
                OPTIONS.maxiter = 5000;
                
                OPTIONS.maxiter_in = 100;
                
                OPTIONS.tol = 1e-5;
                
                tstart = clock;
                
                [xopt1,Fval1,dnorm1,iter1] = VMiPG_dADMM_fLasso(x0, data, OPTIONS, model);
                
                time_list1(nt)= etime(clock,tstart);
                
                xabs1 = abs(xopt1); max_xabs1 = max(xabs1);
                
                xnz_list1(nt) = findnnz(xopt1,0.999); %%length(xabs1(xabs1/max(1,max_xabs1)>1.0e-6));
                
                Bxnz_list1(nt) = findnnz(data.Bmap(xopt1),0.999);
                
                Fval_list1(nt) = Fval1;  iter_list1(nt)=iter1;
                
                dnorm_list1(nt)= dnorm1;
                
            case 'VMiPG-0bfgs'
                
                OPTIONS.maxiter = 10000;
                
                OPTIONS.maxiter_in = 1000;
                
                OPTIONS.tol = 1e-5;
                
                OPTIONS.metric_bfgs =1;
                
                tstart = clock;
                
                [xopt2,Fval2,dnorm2,iter2] = VMiPG_FISTA_fLasso(x0,data,OPTIONS,model);
                
                time_list2(nt)= etime(clock,tstart);
                
                xabs2 = abs(xopt2);  max_xabs2 = max(xabs2);
                
                xnz_list2(nt) = findnnz(xopt2,0.999); %length(xabs2(xabs2/max(1,max_xabs2)>1.0e-6));
                
                Bxnz_list2(nt) = findnnz(data.Bmap(xopt2),0.999);
                
                Fval_list2(nt) = Fval2;  iter_list2(nt)=iter2;
                
                dnorm_list2(nt)= dnorm2;
                
            case 'VMiLA-0bfgs'
                
                OPTIONS.maxiter = 10000;
                
                OPTIONS.maxiter_in = 1000;
                
                OPTIONS.tol = 1e-5;
                
                OPTIONS.metric_bfgs = 1;
                
                tstart = clock;
                
                [xopt3,Fval3,dnorm3,iter3] = VMiLA_FISTA_fLasso(x0,data, OPTIONS, model);
                
                time_list3(nt)= etime(clock,tstart);
                
                xabs3 = abs(xopt3);  max_xabs3 = max(xabs3);
                
                xnz_list3(nt) = findnnz(xopt3,0.999);
                
                Bxnz_list3(nt) = findnnz(data.Bmap(xopt3),0.999); %length(xabs3(xabs3/max(1,max_xabs3)>1.0e-6));
                
                Fval_list3(nt) = Fval3;  iter_list3(nt)=iter3;
                
                dnorm_list3(nt)= dnorm3;
        end

    end
    fprintf('\n---------------------------------------------------------------------------\n');
    fprintf('   Algorithm  |  iter  |    Obj.  |  Residual   |    CPU time   |   axnz | aBxnz \n');
    fprintf('---------------------------------------------------------------------------\n');
    fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \n', 'VMiPG-H', mean(iter_list1),mean(Fval_list1),mean(dnorm_list1), mean(time_list1), mean(xnz_list1),mean(Bxnz_list1));
    fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \n', 'VMiPG-S', mean(iter_list2),mean(Fval_list2),mean(dnorm_list2), mean(time_list2), mean(xnz_list2),mean(Bxnz_list2));
    fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \n', 'VMILA-S', mean(iter_list3),mean(Fval_list3),mean(dnorm_list3),mean(time_list3), mean(xnz_list3),mean(Bxnz_list3));
end