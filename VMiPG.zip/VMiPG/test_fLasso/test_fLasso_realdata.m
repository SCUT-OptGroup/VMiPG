
clear all;

restoredefaultpath;

addpath(genpath('prob_data'));

addpath(genpath('solvers_fLasso'));

addpath(genpath('functions'));

ntest = 1;


Fval_list1 = zeros(ntest,1); time_list1 = zeros(ntest,1); iter_list1 = zeros(ntest,1);
dnorm_list1 = zeros(ntest,1); xnz_list1 = zeros(ntest,1);  Bxnz_list1 = zeros(ntest,1);

Fval_list2 = zeros(ntest,1); time_list2 = zeros(ntest,1); iter_list2 = zeros(ntest,1);
dnorm_list2 = zeros(ntest,1); xnz_list2 = zeros(ntest,1); Bxnz_list2 = zeros(ntest,1);

Fval_list3 = zeros(ntest,1); time_list3 = zeros(ntest,1); iter_list3 = zeros(ntest,1);
dnorm_list3 = zeros(ntest,1); xnz_list3 = zeros(ntest,1);  Bxnz_list3 = zeros(ntest,1);

Fval_list4 = zeros(ntest,1); time_list4 = zeros(ntest,1); iter_list4 = zeros(ntest,1);
dnorm_list4 = zeros(ntest,1); xnz_list4 = zeros(ntest,1);  Bxnz_list4 = zeros(ntest,1);

Fval_list5 = zeros(ntest,1); time_list5 = zeros(ntest,1); iter_list5 = zeros(ntest,1);
dnorm_list5 = zeros(ntest,1); xnz_list5 = zeros(ntest,1);  Bxnz_list5 = zeros(ntest,1);
data_name = {'E2006.train.mat','E2006.test.mat','pyrim_scale_expanded5.mat','bodyfat_scale_expanded7.mat','mpg_scale_expanded7.mat','triazines_scale_expanded4.mat','housing_scale_expanded7.mat'};
alpha1_list = [1e-4,1e-5,50,1e-2,1e-4,100,1e-2];
alpha2_list = [1e-3,1e-1,1e-3,1e-1,1e-1,1e-3,1e-1];
%alpha2_list = [1e-4,1e-2,1e-2,1e-2,1,1e-4,1e-2];
for ii = 5
    dataset = data_name{ii}
    a1 = alpha1_list(ii)
    a2 = alpha2_list(ii)


    %% *****************************************************************

    randstate = 100;
    randn('state',double(randstate));
    rand('state',double(randstate));

    %% ******************daih  problem data ********************************
    load(dataset);
    [m,n] = size(A);

    [Bmap,BTmap] = FLBmap(n);

    Amap  = @(x) A*x;

    ATmap = @(x) A'*x;

    AATmap = @(x) Amap(ATmap(x));

    data.b = b;

    data.Amap = Amap;  data.ATmap = ATmap;

    data.Bmap = Bmap;  data.BTmap = BTmap;

    %% ***************** parameter setting  ***************************

    nu = 0.5;  model.nu = nu;

    Atb_inf = a1*max(abs(ATmap(b)));

    model.lambda = a2*Atb_inf;

    model.lambdaw = Atb_inf*rand(n,1);

    x0 = ATmap(b);

    OPTIONS.printyes = 0;

    method_list = {'VMiPG-H','VMiLA-H','VMiPG-0bfgs','VMiLA-0bfgs'} ;
    
    maxiter = 100000;

    OPTIONS.tol = 1e-7;

    OPTIONS.tol2 = 1e-6;

    for k = 1:4 %length(method_list)

        method = method_list{k};

        switch method

            case 'VMiPG-H'

                OPTIONS.maxiter = maxiter;

                OPTIONS.maxiter_in = 100;


                tstart = clock;

                [xopt1,Fval1,dnorm1,iter1,ttime1,total_in1,total_ls1] = VMiPG_dADMM_fLasso(x0, data, OPTIONS, model);

                xabs1 = abs(xopt1); max_xabs1 = max(xabs1);

                %xnz1 = length(xabs1(xabs1/max(1,max_xabs1)>1.0e-6));

                xnz1 = findnnz(xopt1,0.999);

                Bxnz1 = findnnz(data.Bmap(xopt1),0.999);


            case 'VMiLA-H'

                OPTIONS.maxiter = maxiter;

                OPTIONS.maxiter_in = 100;


                tstart = clock;

                [xopt2,Fval2,dnorm2,iter2,ttime2,total_in2,total_ls2] = VMiLA_dADMM_fLasso(x0, data, OPTIONS, model);

                                xabs2 = abs(xopt2); max_xabs2 = max(xabs2);

                %xnz1 = length(xabs1(xabs1/max(1,max_xabs1)>1.0e-6));

                xnz2 = findnnz(xopt2,0.999);

                Bxnz2 = findnnz(data.Bmap(xopt2),0.999);




            case 'VMiPG-0bfgs'

                OPTIONS.maxiter = maxiter;

                OPTIONS.maxiter_in = 1000;


                OPTIONS.metric_bfgs =1;

                tstart = clock;

                [xopt3,Fval3,dnorm3,iter3,ttime3,total_in3,total_ls3] = VMiPG_FISTA_fLasso(x0,data,OPTIONS,model);

                                xabs3 = abs(xopt3);  max_xabs3 = max(xabs3);

                %xnz2 = length(xabs2(xabs2/max(1,max_xabs2)>1.0e-6));

                xnz3 = findnnz(xopt3,0.999);

                Bxnz3 = findnnz(data.Bmap(xopt3),0.999);


            case 'VMiLA-0bfgs'

                OPTIONS.maxiter = maxiter;

                OPTIONS.maxiter_in = 1000;


                OPTIONS.metric_bfgs = 1;

                tstart = clock;

                [xopt4,Fval4,dnorm4,iter4,ttime4,total_in4,total_ls4] = VMiLA_FISTA_fLasso(x0,data, OPTIONS, model);

                                xabs4 = abs(xopt4);  max_xabs4 = max(xabs4);


                xnz4 = findnnz(xopt4,0.999);

                Bxnz4 = findnnz(data.Bmap(xopt4),0.999);


        end

    end
    fprintf('\n---------------------------------------------------------------------------\n');
    fprintf('   Algorithm  |  iter  |    Obj.  |  Residual   |    CPU time   |   axnz | aBxnz \n');
    fprintf('---------------------------------------------------------------------------\n');
    fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \t %4.3f \t %4.3f \n', 'VMiPG-H', iter1,Fval1,dnorm1,ttime1,xnz1,Bxnz1,total_in1,total_ls1);
    fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \t %4.3f \t %4.3f \n', 'VMiLA-H', iter2,Fval2,dnorm2,ttime2,xnz2,Bxnz2,total_in2,total_ls2);
    fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \t %4.3f \t %4.3f \n', 'VMIPG-0bfgs', iter3,Fval3,dnorm3,ttime3,xnz3,Bxnz3,total_in3,total_ls3);
    fprintf('%12s: \t %3d \t  %4.3f \t  %3.2e \t  %3.2f\t  %4.3f \t %4.3f \t %4.3f \t %4.3f \n', 'VMILA-0bfgs', iter4,Fval4,dnorm4,ttime4,xnz4,Bxnz4,total_in4,total_ls4);
end