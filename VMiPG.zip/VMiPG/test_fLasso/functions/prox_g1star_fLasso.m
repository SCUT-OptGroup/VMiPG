%% ****************************************************************
%  filename: prox_g1star_fLasso
%% ****************************************************************
% this code is used to compute prox_{gamma g^*}(z);
% g = ||Bx||_1, B is fused lasso operator
% where mexCondat is the solver for seeking the optimal solution of 
% min (1/2*tau)||x-z||^2 + ||Bx||_1
%% ****************************************************************

function [projz]= prox_g1star_fLasso(z,lambda,gamma)

temp_prox = TV_Condat(z/gamma,lambda/gamma);  %_tautString_mex  %mexCondat

projz = z-gamma*temp_prox;

end
