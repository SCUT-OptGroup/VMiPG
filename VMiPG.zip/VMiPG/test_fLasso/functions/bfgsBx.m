%************************************************************************
% filename: bfgsBx
%************************************************************************
%% to compute Bx, which is exactly Gk(x) in our paper
%%
function Bx = bfgsBx(x,s,y)

tau = dot(s,y)/norm(y)^2;

sqynorm = norm(y)^2; sqsnorm = norm(s)^2;

Bx = x - (dot(s,x)/sqsnorm)*s + (dot(y,x)/sqynorm)*y;

Bx = Bx/tau;



