%% **********************************************************************
%  filename: gfun
%% **********************************************************************
%  gfun(x) = g_1(x)+g_2(x)
%
%  where g_1(x) = lambda*||Bx||_1  and g_2(x)= delta_{[lb,ub]}(x)

function gval = gfun(x,data,lambda)

gval = lambda*norm(data.Bmap(x),1);
