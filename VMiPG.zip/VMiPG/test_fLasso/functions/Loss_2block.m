function [fval,grad,dd] = Loss_2block(Ax,b,data,nu)

Axb = Ax-b;

Axb_sq = Axb.^2;

fval = sum(log(1+Axb_sq/nu));

if nargout >=3
    
    grad = 2*data.ATmap(Axb./(nu+Axb_sq));
    
    dd = 2*(nu-Axb_sq)./(nu+Axb_sq).^2;
    
elseif nargout>=2

    grad = 2*data.ATmap(Axb./(nu+Axb_sq));
end
end