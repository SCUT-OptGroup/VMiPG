function projz = Proj_box(z,L,U)
projz = min(max(L,z),U);
end

% function [Hx] = call_box_proxjacobi(z,x, gam, L,U)
% 
% Hx = z;
% 
% Hx(x>=U)=0;
% 
% Hx(x<=L)=0;
% 
% end
% 
% function conjgval = call_box_conjgval(L,U,x,gam)
% n = length(x);
% 
% z = zeros(n,1);
% 
% z(x>L)=U;
% 
% conjgval = z'*x;
% 
% end