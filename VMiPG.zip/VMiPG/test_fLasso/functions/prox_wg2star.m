%% ****************************************************************
%   filename: prox_wg2star
%% ****************************************************************
% Case 1: wg2(x) = delta_{[lb,ub]}(x)+0.5*mu*||x||^2
%         wg2star is the conjugate function of wg2
%         to compute the proximal mapping and the moreal envelope of wg2star 

function [projz,zprojz,Mwg2star]= prox_wg2star(z,lb,ub,mu,gamma)

gam_mu = gamma+mu;

tempz = z/gam_mu;

temp_projz = min(max(lb,tempz),ub);

zprojz = gamma*temp_projz;

projz = z-zprojz;

if nargout>=2
  
   Mwg2star = 0.5*gam_mu*norm(temp_projz-tempz)^2+(0.5/gam_mu)*norm(z)^2;
   
end   
end