function gval = gfun_fLasso(x,data,lambda,lambdaw)

gval = lambda*norm(data.Bmap(x),1)+norm(lambdaw.*x,1);
