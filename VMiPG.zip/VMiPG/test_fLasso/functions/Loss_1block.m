%% ***************************************************************
% filename: Loss_1block
%% ***************************************************************

function [obj,grad,dd] = Loss_1block(Ax,ATmap,bg,gn,nzidx,ATe)

rapp = zeros(size(gn));

den = Ax + bg;

rapp(nzidx) = gn(nzidx)./den(nzidx);

obj = sum(gn(nzidx).*(log(rapp(nzidx))-1))+sum(den(:));

if nargout>=3
    
    dd = zeros(size(gn));
  
    grad = ATe - ATmap(rapp);
    
    dd(nzidx) = gn(nzidx)./(den(nzidx).^2);
    
elseif nargout>=2
    
    grad = ATe - ATmap(rapp);    
end
end