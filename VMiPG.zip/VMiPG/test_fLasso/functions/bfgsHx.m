%************************************************************************
% filename: bfgsHx
%************************************************************************
%% to compute Hx, which is exactly Gk^{-1}(x) in our paper
%%
function Hx = bfgsHx(x,s,y)

rho = 1/dot(s,y);

tau = dot(s,y)/norm(y)^2;

u = s-0.5*tau*y;

Hx = tau*x +2*rho*dot(u,x)*u-rho*0.5*tau^2*dot(y,x)*y;