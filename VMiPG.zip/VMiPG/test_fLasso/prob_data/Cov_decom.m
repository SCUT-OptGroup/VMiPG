%% ****************************************************************
%  filename:getData_snoise
%
%% ****************************************************************
%% to generate the examples with sparse noise 

function [C] = Cov_decom(n,p,Covtype)

%% *********************** generate A ****************************

switch Covtype
    
    
    case 2  %AR0.5
        
        SigmaX = zeros(p);
        
        for i=1:p
            
            for j=i+1:p
                
                SigmaX(i,j) = 0.3^(abs(i-j));
                
            end
        end
        
        S = SigmaX + SigmaX'+ eye(p); 
        
    case 3  %AR0.8
        
        SigmaX = zeros(p);
        
        for i=1:p
            
            for j=i+1:p
                
                SigmaX(i,j) = 0.8^(abs(i-j));
                
            end
            
        end
        
        S = SigmaX + SigmaX'+ eye(p);
        
    case 4  %CS0.6
        
        alpha = 0.6;
        
        S = alpha*ones(p)+(1-alpha)*eye(p);
        
    case 5  %CS0.8
        
        alpha = 0.8;
        
        S = alpha*ones(p)+(1-alpha)*eye(p);
end

[U,D] = eig(S);

dd = diag(D);

C = U*diag(dd.^(1/2));

