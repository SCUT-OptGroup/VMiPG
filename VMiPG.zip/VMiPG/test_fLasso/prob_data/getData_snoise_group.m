%% ****************************************************************
%  filename:getData_snoise
%
%% ****************************************************************
%% to generate the examples with sparse noise 

function [A,b,xs,supp_noise,err_norm] = getData_snoise_group(n,p,ncopy,Covtype,errtype,randstate,C)

randn('state',double(randstate));

rand('state',double(randstate));

%% ****************** get original signal **********************

gdim = floor(p/ncopy);

x0 = [0,0,-1.5,-1.5,-2,-2,0,0,1,1,4,4,4];

x0 = [x0,zeros(1,gdim-length(x0))]; 

x0 = x0';

xs = [];

for i =1:ncopy
    
    xs = [xs;x0];
    
end


%% *********************** generate A ****************************
if Covtype~= 0
    
    tempC = C*randn(p,n);
    
    A = tempC';
else
    A = randn(n,p);
end    
    
%% ************************ generate noise **********************

rn = randperm(n);

sn = floor(0.3*n);

err = zeros(n,1);

switch errtype
    
    case 1  % the distribution N(0,4)
        
        err(rn(1:sn)) = 2*randn(sn,1);
        
    case 2  % the scaled Student's t-distribution with 4 degrees of freedom
        
        err(rn(1:sn)) = sqrt(2)*trnd(4,sn,1);
        
    case 3  %the Cauchy distribution with density d(u)=(1/pi)*(1/(1+u^2))
        
        temp_err = rand(sn,1);
        
        err(rn(1:sn)) = tan((temp_err-1/2)*pi);
        
    case 4  % the mixture normal distribution
        
        unif = 1 + 4*rand(sn,1);
        
        err(rn(1:sn)) = unif.*randn(sn,1);
        
    case 5  % the Laplace distribution with density d(u)=0.5*exp(-|u|)
        
        temp_err = rand(sn,1)-0.5;
        
        err(rn(1:sn)) = 0 - sign(temp_err).*log(1-2*abs(temp_err));
        
            case 6  % no noise
        
           err = 0;
end

supp_noise = rn(1:sn);

b = A*xs+err;

err_norm = norm(err);

end


 
 

