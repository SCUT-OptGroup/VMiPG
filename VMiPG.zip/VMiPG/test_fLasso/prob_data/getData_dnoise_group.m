%% ****************************************************************
%  filename:getData_snoise
%
%% ****************************************************************
%% to generate the examples with sparse noise 

function [A,b,xs,supp_noise,err_norm] = getData_dnoise_group(n,p,ncopy,Covtype,errtype,randstate,C)

randn('state',double(randstate));

rand('state',double(randstate));

%% ****************** get original signal **********************

gdim = floor(p/ncopy);

x0 = [0,0,-1.5,-1.5,-2,-2,0,0,1,1,4,4,4];

x0 = [x0,zeros(1,gdim-length(x0))]; 

x0 = x0';

xs = [];

for i =1:ncopy
    
    xs = [xs;x0];
    
end


%% *********************** generate A ****************************
if Covtype~=1
    
    tempC = C*randn(p,n);
    
    A = tempC';
else
    A = randn(n,p);
end    
    
%% ************************ generate noise **********************

rn = randperm(n);

err = zeros(n,1);

switch errtype
    
    case 1  % the distribution N(0,4)
        
        err(rn) = 2*randn(n,1);
        
    case 2  % the scaled Student's t-distribution with 4 degrees of freedom
        
        err(rn) = sqrt(2)*trnd(4,n,1);
        
    case 3  %the Cauchy distribution with density d(u)=(1/pi)*(1/(1+u^2))
        
        temp_err = rand(n,1);
        
        err(rn) = tan((temp_err-1/2)*pi);
        
    case 4  % the mixture normal distribution
        
        unif = 1 + 4*rand(n,1);
        
        err(rn) = unif.*randn(n,1);
        
    case 5  % the Laplace distribution with density d(u)=0.5*exp(-|u|)
        
        temp_err = rand(n,1)-0.5;
        
        err(rn) = 0 - sign(temp_err).*log(1-2*abs(temp_err));
end

supp_noise = rn(1:n);

b = A*xs+err;

err_norm = norm(err);

end


 
 

