%% ****************************************************************
%  filename:getData_snoise
%
%% ****************************************************************
%% to generate the examples with sparse noise

function [C] = CovMat_group(ngroup,p,gdim,Covtype)

%% *********************** generate A ****************************

switch Covtype
    
    case 1
        
        SigmaX = zeros(p);
        
        for ng = 1:ngroup
            
            for i=(gdim*(ng-1)+1):gdim*ng
                
                for j=i+1:gdim*ng
                    
                    SigmaX(i,j) = 0.3^(abs(i-j));
                    
                end
            end
        end
        
        S = SigmaX + SigmaX'+ eye(p);
        
    case 2
        
        SigmaX = zeros(p);
        
        for ng = 1:ngroup
            
            for i=(gdim*(ng-1)+1):gdim*ng
                
                for j=i+1:gdim*ng
                    
                    SigmaX(i,j) = 0.8^(abs(i-j));
                    
                end
            end
        end
        
        S = SigmaX + SigmaX'+ eye(p);
        
    case 4  %CS0.6
        
        alpha = 0.6;
        
        S = alpha*ones(p)+(1-alpha)*eye(p);
        
    case 5  %CS0.8
        
        alpha = 0.8;
        
        S = alpha*ones(p)+(1-alpha)*eye(p);
end

[U,D] = eig(S);

dd = diag(D);

C = U*diag(dd.^(1/2));

