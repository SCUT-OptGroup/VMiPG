%% **********************************************************************
%  filename: VMiPG_SNdADMM_Cauchy
%% **********************************************************************
%% to solve the following composite optimization problem
%
%  min{x}{theta(Ax-b)+ g_1(Bx)+g_2(x)}
%
% Each step is to seek an inexact minimizer yk of the strongly convex program
%
% min_{x}{0.5*||Ak(x)||^2-<bk,x>+g_1(x)+wg_2(x)}
%
%% ******************************************************************

function [xopt,Fval,dnorm,iter,ttime,total_in,total_ls,Iter_list] = VMiPG_SNdADMM_Cauchy(x,data,OPTIONS,model,lambda)

if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'maxiter_in');   maxiter_in  = OPTIONS.maxiter_in;    end
if isfield(OPTIONS,'tol');          tol         = OPTIONS.tol;           end
if isfield(OPTIONS,'tol2');          tol2         = OPTIONS.tol2;           end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end

[nr,nc] = size(x);  %% x is a matrix 

b = data.gn;

if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n VMiLA for solving nonnegative TV regularization problem with dADMM_BSN');
    fprintf('\n *****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter   subit  ls       dnorm             Fval         time        sigma        dual_gap');
end

%% ***************** Initialization part for dADMM ***************

OPTIONS_ADMM.maxiter = maxiter_in;

OPTIONS_ADMM.printyes = 0;

OPTIONS_ADMM.sigma = 1;

OPTIONS_ADMM.sigma_flag = 1;

OPTIONS_ADMM.Bsnorm = 9;

mu = 1e-5;  

delta = 3e-6;  beta = 0.1; 

xi = zeros(nr,nc);  

zeta1 = xi; zeta2 = xi;

%% *************************** main loop **************************

iter = 1;

total_in = 0;

total_ls = 0;

tstart = clock;

Ax = data.Amap(x);

[fval,grad,Dx] = Loss_2block(Ax,b,data,model);

dx1 = data.Bp1(x);  dx2 = data.Bp2(x);

tempdvec = sqrt(dx1.^2+dx2.^2);

gval = lambda*sum(tempdvec(:));

Fval = fval + gval;

Fval0 = abs(Fval);

Iter_list = [];

while (iter<=maxiter)
        
 % Compute Lambda at x where the hessian of f takes the form of A'*diag(Dx)*A
   
    Lambda = -min(0,Dx);
    
%% **************** sole the subproblem with DALMQ ****************
   % initialize Ainput = D_{+}^(1/2)A and binput
    
    Dxp = Dx + Lambda;
    
    adax = data.ATmap(Dxp.*Ax);
     
    binput = adax + mu*x - grad;

    OPTIONS_ADMM.normb = norm(binput,'fro');
    
    sqrtDxp = Dxp.^(1/2);
        
    Amap = @(x) sqrtDxp.*data.Amap(x);
     
    ATmap = @(x) data.ATmap(sqrtDxp.*x);
     
    info.epsk = 1e+7/iter^(1.5);
    
    info.qks = 0.5*(sum(dot(x,adax))+mu*norm(x,'fro')^2)-sum(dot(grad,x));

    info.gval = gval;
    
    [y,xi,zeta1,zeta2,sigma,admm_it,resi_in, pobj, dobj] = dADMM_BSN(xi,ATmap(xi),zeta1,zeta2,x,OPTIONS_ADMM,Amap,ATmap,binput,mu,info,data,lambda);
    
    OPTIONS_ADMM.sigma = sigma;
        
    total_in = total_in + admm_it;        
%==========================================================================
    Ay = data.Amap(y);
    
    fval_y = Loss_2block(Ay,b,data,model);
    
    dy1 = data.Bp1(y); dy2 = data.Bp2(y);
    
    tempdvec = sqrt(dy1.^2+dy2.^2);
    
    gval_y = lambda*sum(tempdvec(:));
    
    Fval_y = fval_y + gval_y;
    
    d = y - x;  Ad = Ay - Ax;
    
    dnorm = norm(d,'fro');
    
    if (dnorm < tol)
        xopt = x;
        return;
    end
    
 %% ********************* perform line search ***********************
    
    ls = 0;
    
    descent = delta*dnorm^2;
    
    xnew = y;  Axnew = Ay;  Fval_new = Fval_y;
    
    while (Fval_new > Fval - beta^(ls)*descent)
        
        ls = ls + 1;
        
        xnew = x + beta^(ls)*d;
        
        Axnew = Ax+beta^(ls)*Ad;
        
        fval_new = Loss_2block(Axnew,b,data,model);
        
        dxnew1 = data.Bp1(xnew); dxnew2 = data.Bp2(xnew);
        
        tempdvec = sqrt(dxnew1.^2+dxnew2.^2);
        
        gval_new = lambda*sum(tempdvec(:));
        
        Fval_new = fval_new + gval_new;
    end
    
    total_ls = total_ls+ls;
    %% ***************** Update iterate **************************

    if (Fval_y < Fval_new)||(ls==0)
        
        x = y;  Ax = Ay;
        
        gval = gval_y;  Fval = Fval_y;
        
    else
        
        x = xnew; Ax = Axnew;
        
        gval = gval_new;  Fval = Fval_new;
    end
    
    ttime = etime(clock,tstart);
    
    if (printyes)
        
        fprintf('\n %2d     %2d     %2d        %4.3e        %5.3f       %3.1f       %3.2e    %3.2e',iter,admm_it,ls,dnorm,Fval,ttime,sigma,resi_in)
        
    end
   
    if(iter>10)&&(max(abs(Fval-Fval_list(iter-10:iter-1)))<=tol2*max(1,abs(Fval)))
        
        xopt = x;
        
        return;
    end
            
    [fval,grad,Dx] = Loss_2block(Ax,b,data,model);
    
    Fval_list(iter) = Fval;
    
    iter = iter + 1;
    
    Iter_list = [Iter_list x(:)];
end

xopt = x;

end
