function [xbar,w1,w2,w3,resi_in,iter,hfun] = FISTA_1block_VMiLA(x,tw1,tw2,tw3,gamma,lambda,alpha,dmat,avec,data,OPTIONS,info)

if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end
if isfield(OPTIONS,'extra_con');    extra_con   = OPTIONS.extra_con;     end
if isfield(OPTIONS,'metric_bfgs');  metric_bfgs  = OPTIONS.metric_bfgs;  end

Ck = info.Ck;

xk = x;

%% initialization

w1old = tw1;  w2old = tw2; w3old = tw3;


BTtw = data.Bt(tw1,tw2)+tw3;    BTw = BTtw;

if metric_bfgs

    diffx = info.diffx; diffg = info.diffg;

    Gkak = (1/alpha)*bfgsBx_matrix(avec,diffx,diffg);

    y = avec - alpha*bfgsHx_matrix(BTtw,diffx,diffg);

else

    alp_dmat = alpha./dmat;

    y = avec - alp_dmat.*BTtw;

end


for iter = 1:maxiter

    w1 = tw1 + gamma*data.Bp1(y);    % gamma = 1/Lip

    w2 = tw2 + gamma*data.Bp2(y);

    w3 = tw3 + gamma*y;

    %% ****************** proximal step *************************

    R = sqrt(w1.^2 + w2.^2);

    I = R > lambda;

    w1(I) = lambda*w1(I)./R(I);

    w2(I) = lambda*w2(I)./R(I);

    w3(w3>0) = 0;

    BTwold = BTw;

    BTw = data.Bt(w1,w2) + w3;

    %% *************** dual objective value **************************
    if metric_bfgs

        tempw = avec - alpha*bfgsHx_matrix(BTw,diffx,diffg);

        dvecw =(1/alpha)*bfgsBx_matrix(tempw,diffx,diffg);

        dobj = 0.5*sum(dot(tempw,dvecw));

        xbar = max(tempw+tw3,0);

        dybar1 = data.Bp1(xbar); dybar2 = data.Bp2(xbar);

        normybar = sqrt(dybar1.^2+dybar2.^2);

        gxbar = lambda*sum(normybar(:));

        dvec_ybar = (1/alpha)*bfgsBx_matrix(xbar,diffx,diffg);

        pobj = 0.5*sum(dot(xbar,dvec_ybar))-sum(dot(Gkak,xbar))+gxbar;


    else

        tempw = avec - alp_dmat.*BTw;

        dobj = (0.5/alpha)*(dmat(:)'*tempw(:).^2);

        %% ************** to recover the primal feasibility **************

        xbar = max(tempw+tw3,0);

        dybar1 = data.Bp1(xbar); dybar2 = data.Bp2(xbar);

        normybar = sqrt(dybar1.^2+dybar2.^2);

        gxbar = lambda*sum(normybar(:));

        pobj =(1/alpha)*(0.5*sum(dot(xbar,dmat.*xbar))-sum(dot(dmat.*avec,xbar)))+gxbar;

    end

    resi_in = abs(pobj+dobj);

    if printyes
        fprintf('\n    %3g)  hsigmaplus %g psi %g dual gap %g',iter,pobj,dobj,resi_in);
    end
    
    hfun = pobj+Ck;
    
    if (pobj+info.qks<info.gval)&&(hfun<=2*(-dobj+Ck)/(2+info.epsk))
        
        return;        
    end

    %% ******************* extrapolation step *********************

    beta = (iter-1)/(iter + extra_con);

    tw1 = w1 + beta*(w1-w1old);

    tw2 = w2 + beta*(w2-w2old);

    tw3 = w3 + beta*(w3-w3old);

    w1old = w1; w2old = w2; w3old = w3;

    BTtw = BTw + beta*(BTw - BTwold);

    if metric_bfgs

        y = avec - alpha*bfgsHx_matrix(BTtw,diffx,diffg);
    else


        y = avec - alp_dmat.*BTtw;

    end

end
