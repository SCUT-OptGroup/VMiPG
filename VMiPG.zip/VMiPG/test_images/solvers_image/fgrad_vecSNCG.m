%% ***************************************************************
%  To compute the function and gradient values of Phi_j  
%
%% ***************************************************************

function [proxu,uproxu,fval] = fgrad_SNCG(xi,u,sigma,mu,lb,ub)

[proxu,uproxu,Mwg2star] = prox_wg2star(u,lb,ub,mu,1/sigma);

fval = 0.5*norm(xi,'fro')^2 + Mwg2star;  

end