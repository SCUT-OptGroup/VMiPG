%% ***************************************************************
%  Given vector d, calculate 
%
%  Ad = d + sigma_mu*Anz(Anzt(d))
%  
%  sigma = <d,Ad> = ||d||^2 + sigma_mu*||Anzt(d)||^2
%
%% **************************************************************

function [Ad,sigma] = Jac_matSNCG(Amap,nzind,d,Atd,sigma_mu)

Anztd = Atd.*nzind;

Ad = d + sigma_mu*Amap(Anztd);

sigma = norm(d,'fro')^2 + sigma_mu*norm(Anztd,'fro')^2;

end
