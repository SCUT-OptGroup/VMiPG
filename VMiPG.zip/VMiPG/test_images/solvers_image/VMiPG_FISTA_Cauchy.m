function [xopt,Fval,dnorm,iter,ttime] = VMiPG_FISTA_Cauchy(x,data,OPTIONS,model,lambda)
%%
%  This is the VMLS method for solving the following nonconvex composite problem
%  min{ theta(Ax-b)+ g1(Bx) + g2(x)}
%  In each iterate, this method is solving the following subproblem
%
%% ****************************************************************
if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'maxiter_in');   maxiter_in  = OPTIONS.maxiter_in;    end
if isfield(OPTIONS,'tol');          tol         = OPTIONS.tol;           end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end
if isfield(OPTIONS,'metric');       metric      = OPTIONS.metric;        end

n = size(x,1);  % here x is a matrix

nu = model.nu;

b = data.gn;

if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n iVMLS for solving l1-regularization regression with fista');
    fprintf('\n *****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter   iter_in  ls     dnorm           Fval          time         resi-in     alpha');
end

%% ***************** Initialization part for FISTA ***************

OPTIONS_FISTA.maxiter = maxiter_in;

OPTIONS_FISTA.printyes = 0;

OPTIONS_FISTA.extra_con = 2.1;

P = 1e10;  p = 2;

mu = 1e-5;

delta = min(1,mu)/2;  beta = 0.1;

alpha = 1.3;  alpha_min = 1e-5;  alpha_max = 1e2;

tau = 0.5;  lm = 3;

Valpha = 1e30*ones(lm,1);

Ax = data.Amap(x);

switch metric
    
    case 'SG'
        
        soglia_X_low = 1e-10;
        
        soglia_X_upp = 1e+10;   % threshold on scaling matrix
        
        Hxb = Ax-b;
        
        Hxb_sq = Hxb.^2;
        
        tempx = data.ATmap(Ax./(nu^2+Hxb_sq));
        
        X = x./(tempx+1e-4);
       
        X(X < soglia_X_low) = soglia_X_low;
        
        X(X > soglia_X_upp) = soglia_X_upp;
        
        dmat = 1./X;
        
    case 'I'
        
        dmat = ones(n,n);
end

%% ************************* main loop **************************

iter = 1;

total_in = 0;

v1 = zeros(n,n);  v2 = v1; v3 = v2;

tstart = clock;

[fval,grad] = Loss_2block(Ax,b,data,model);

dx1 = data.Bp1(x); dx2 = data.Bp2(x);

tempdvec = sqrt(dx1.^2+dx2.^2);

gval = lambda*sum(tempdvec(:));

Fval = fval + gval;

Fval0 = abs(Fval);

while (iter<=maxiter)
    
    Valpha(1:lm-1) = Valpha(2:lm);
    
    %% **************** sole the subproblem with FISTA *************
    
    inv_gradLip = min(dmat(:))/(alpha*9);
    
    avec = x - alpha*(grad./dmat);
    
    info.epsk = Fval0/iter^(0.01);
    
    info.gval = gval;
    
    info.qks = (0.5/alpha)*sum(dot(x,x.*dmat))-sum(dot(grad,x));
    
    [y,v1,v2,v3,resi_in,fista_iter] = FISTA_1block(x,v1,v2,v3,inv_gradLip,lambda,alpha,dmat,avec,data,OPTIONS_FISTA,info);
    
    total_in = total_in + fista_iter;
    
    %==========================================================================
    Ay = data.Amap(y);
    
    fval_y = Loss_2block(Ay,b,data,model);
    
    dy1 = data.Bp1(y); dy2 = data.Bp2(y);
    
    tempdvec = sqrt(dy1.^2+dy2.^2);
  
    gval_y = lambda*sum(tempdvec(:));
    
    Fval_y = fval_y + gval_y;
    
    d = y - x;   Ad = Ay - Ax;
    
    dnorm = norm(d,'fro');
    
    if (dnorm < tol)
        xopt = x;
        return;
    end
    
    %% ********************* perform line-search *********************
    
    ls = 0;
    
    descent = delta*dnorm^2;
    
    xnew = y;  Axnew = Ay;  Fval_new = Fval_y;
    
    while (Fval_new > Fval - beta^(ls)*descent)
        
        ls = ls + 1;
        
        xnew = x + beta^(ls)*d;
        
        Axnew = Ax+beta^(ls)*Ad;
        
        fval_new = Loss_2block(Axnew,b,data,model);
        
        dxnew1 = data.Bp1(xnew); dxnew2 = data.Bp2(xnew);
        
        tempdvec = sqrt(dxnew1.^2+dxnew2.^2);
        
        gval_new = lambda*sum(tempdvec(:));
        
        Fval_new = fval_new + gval_new;
    end
    
    %% ****************** Making update ****************************
    
    if (Fval_y<Fval_new)||(ls==0)
        
        diffx = y - x;
        
        x = y;  Ax = Ay;
        
        gval = gval_y;  Fval = Fval_y;
        
    else
        diffx = xnew - x ;
        
        x = xnew; Ax = Axnew;
        
        gval = gval_new;  Fval = Fval_new;
    end
    
    ttime = etime(clock,tstart);
    
    if (printyes)
        
        fprintf('\n %2d     %3d     %2d      %4.3e      %4.3f     %3.2f       %3.2e     %3.2e',iter,fista_iter,ls,dnorm,Fval,ttime,resi_in,alpha)
        
    end
    
    if(iter>10)&&(max(abs(Fval-Fval_list(iter-10:iter-1)))<=1.0e-8*max(1,abs(Fval)))
        
        xopt = x;
        
        return;
    end
    
    %% ********************* update dmat ***************************
    
    [~,gradnew] = Loss_2block(Ax,b,data,model);
    
    diffg = gradnew - grad;
    
    grad = gradnew;
    
    switch metric
        
        case 'SG'
                        
            soglia_X_upp = sqrt(1+P/iter^p);
            
            soglia_X_low = 1/soglia_X_upp;
                    
            Hxb = Ax-b;
            
            Hxb_sq = Hxb.^2;
                        
            tempx = data.ATmap(Ax./(nu^2+Hxb_sq));
            
            X = x./(tempx+1e-4);
            
            X(X<soglia_X_low) = soglia_X_low;
            
            X(X>soglia_X_upp) = soglia_X_upp;
            
            dmat = 1./X;
            
        case 'I'
            
    end
    
    diffx2 = diffx.*dmat;   diffg2 = diffg.*X;
    
    bk_const = sum(dot(diffx2,diffg));  ck_const = sum(dot(diffg2,diffx));
    
    if (bk_const <= 0)
        
        alpha1 = alpha_max;
    else
        
        alpha1BB = norm(diffx2,'fro')^2/bk_const;
        
        alpha1 = min(alpha_max, max(alpha_min, alpha1BB));
    end
    
    if (ck_const <= 0)
        
        alpha2 = alpha_max;
    else
        
        alpha2BB = ck_const/norm(diffg2,'fro')^2;
        
        alpha2 = min(alpha_max, max(alpha_min, alpha2BB));
    end
    
    Valpha(lm) = alpha2;
    
    if (alpha2/alpha1<tau)
        
        alpha = min(Valpha);
        
        tau = tau*0.9;
    else
        alpha = alpha1;
        
        tau = tau*1.1;
    end
    
    Fval_list(iter) = Fval;
    
    iter = iter + 1;
    
end

xopt = x;

end

