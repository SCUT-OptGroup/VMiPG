function [xopt,Fval,dnorm,iter,ttime,total_in,total_ls,Iter_list] = VMiPG_FISTA_Cauchy(x,data,OPTIONS,model,lambda)
%%
%  This is the VMLS method for solving the following nonconvex composite problem
%  min{ theta(Ax-b)+ g1(Bx) + g2(x)}
%  In each iterate, this method is solving the following subproblem
%
%% ****************************************************************
if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'maxiter_in');   maxiter_in  = OPTIONS.maxiter_in;    end
if isfield(OPTIONS,'tol');          tol         = OPTIONS.tol;           end
if isfield(OPTIONS,'tol2');          tol2         = OPTIONS.tol2;           end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end
if isfield(OPTIONS,'metric');       metric      = OPTIONS.metric;        end
if isfield(OPTIONS,'metric_bfgs');  metric_bfgs  = OPTIONS.metric_bfgs;   end

n = size(x,1);  % here x is a matrix

nu = model.nu;

b = data.gn;

if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n iVMLS for solving l1-regularization regression with fista');
    fprintf('\n *****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter   iter_in  ls     dnorm           Fval          time         resi-in     alpha');
end

%% ***************** Initialization part for FISTA ***************

OPTIONS_FISTA.maxiter = maxiter_in;

OPTIONS_FISTA.printyes = 0;

OPTIONS_FISTA.metric_bfgs = metric_bfgs;

OPTIONS_FISTA.extra_con = 2.1;

%P = 1e10;  p = 2;
%% ***************** Initialization part for VMLS ****************

mu = 1e-5;  delta = 3e-6;  beta = 0.1;

alpha = 1.3;  alpha_min = 1e-5;  alpha_max = 1e2;

tau = 0.5;  lm = 3;

Valpha = 1e30*ones(lm,1);

%% ********************* main loop ******************************

iter = 1;

total_in = 0;

total_ls = 0;

v1 = zeros(n,n);  v2 = v1; v3 = v2;

tstart = clock;

Ax = data.Amap(x);

[fval,grad] = Loss_2block(Ax,b,data,model);

dx1 = data.Bp1(x); dx2 = data.Bp2(x);

tempdvec = sqrt(dx1.^2+dx2.^2);

gval = lambda*sum(tempdvec(:));

Fval = fval + gval;

Fval0 = abs(Fval);

if metric_bfgs

    diffx = x; diffg = grad;

    Hksnorm = tau+(1/sum(dot(diffx,diffg)))*(2*norm(diffx-0.5*tau*diffg,'fro')^2+0.5*tau^2*norm(diffg,'fro')^2);

    info.diffx = x;  info.diffg = grad;

else

    switch metric

        case 'SG'

            soglia_X_low = mu;

            soglia_X_upp = 1/mu;   % threshold on scaling matrix

            Hxb = Ax-b;

            Hxb_sq = Hxb.^2;

            tempx = data.ATmap(Ax./(nu^2+Hxb_sq));

            X = x./(tempx+1e-10);

            X(X < soglia_X_low) = soglia_X_low;

            X(X > soglia_X_upp) = soglia_X_upp;

            dmat = 1./X;

        case 'I'

            dmat = ones(n,n);

            X = dmat;
    end
end

Iter_list = [];
%% ************************* main loop **************************


while (iter<=maxiter)

    Valpha(1:lm-1) = Valpha(2:lm);

    %% **************** sole the subproblem with FISTA *************
    info.epsk = 1e+7/iter^(1.5);

    info.gval = gval;

    if metric_bfgs

        inv_gradLip = 0.5/(9*Hksnorm*alpha);

        avec = x - alpha*(bfgsHx_matrix(grad,info.diffx,info.diffg));

        dvecx = bfgsBx_matrix(x,info.diffx,info.diffg);

        info.qks =(0.5/alpha)*sum(dot(x,dvecx))-sum(dot(grad,x));

        [y,v1,v2,v3,resi_in,fista_iter] = FISTA_1block(x,v1,v2,v3,inv_gradLip,lambda,alpha,[],avec,data,OPTIONS_FISTA,info);

    else

        inv_gradLip = min(dmat(:))/(alpha*9); %need check???why 9

        avec = x - alpha*(grad./dmat);

        info.qks = (0.5/alpha)*sum(dot(x,x.*dmat))-sum(dot(grad,x));

        [y,v1,v2,v3,resi_in,fista_iter] = FISTA_1block(x,v1,v2,v3,inv_gradLip,lambda,alpha,dmat,avec,data,OPTIONS_FISTA,info);

    end
    total_in = total_in + fista_iter;

    %==========================================================================
    Ay = data.Amap(y);

    fval_y = Loss_2block(Ay,b,data,model);

    dy1 = data.Bp1(y); dy2 = data.Bp2(y);

    tempdvec = sqrt(dy1.^2+dy2.^2);

    gval_y = lambda*sum(tempdvec(:));

    Fval_y = fval_y + gval_y;

    d = y - x;   Ad = Ay - Ax;

    dnorm = norm(d,'fro');

    if (dnorm < tol)
        xopt = x;
        return;
    end

    %% ********************* perform line-search *********************

    ls = 0;

    descent = delta*dnorm^2;

    xnew = y;  Axnew = Ay;  Fval_new = Fval_y;

    while (Fval_new > Fval - beta^(ls)*descent)

        ls = ls + 1;

        xnew = x + beta^(ls)*d;

        Axnew = Ax+beta^(ls)*Ad;

        fval_new = Loss_2block(Axnew,b,data,model);

        dxnew1 = data.Bp1(xnew); dxnew2 = data.Bp2(xnew);

        tempdvec = sqrt(dxnew1.^2+dxnew2.^2);

        gval_new = lambda*sum(tempdvec(:));

        Fval_new = fval_new + gval_new;
    end

    total_ls = total_ls+ls;

    %% ****************** Making update ****************************

    if (Fval_y<Fval_new)||(ls==0)

        diffx = y - x;

        x = y;  Ax = Ay;

        gval = gval_y;  Fval = Fval_y;

    else
        diffx = xnew - x ;

        x = xnew; Ax = Axnew;

        gval = gval_new;  Fval = Fval_new;
    end

    ttime = etime(clock,tstart);

    if (printyes)

        fprintf('\n %2d     %3d     %2d      %4.3e      %4.3f     %3.2f       %3.2e     %3.2e',iter,fista_iter,ls,dnorm,Fval,ttime,resi_in,alpha)

    end

    if(iter>10)&&(max(abs(Fval-Fval_list(iter-10:iter-1)))<=tol2*max(1,abs(Fval)))

        xopt = x;

        return;
    end

    %% ********************* update dmat ***************************

    [~,gradnew] = Loss_2block(Ax,b,data,model);

    diffg = gradnew - grad;

    grad = gradnew;

    if metric_bfgs

        dot_xg = sum(dot(diffx,diffg));

        sqnorm_diffg = norm(diffg,'fro')^2;

        tau1 = norm(diffx,'fro')^2/dot_xg;

        tau2 = dot_xg/sqnorm_diffg;

        if tau1<=1e+10 && tau2>=1e-10

            info.diffx = diffx;  info.diffg = diffg;

            Hksnorm = tau2+(1/dot_xg)*(2*norm(diffx-0.5*tau2*diffg,'fro')^2 +0.5*tau2^2*sqnorm_diffg);

        end

        diffx2 = bfgsBx_matrix(diffx,info.diffx,info.diffg);

        diffg2 = bfgsHx_matrix(diffg,info.diffx,info.diffg);

    else

        switch metric

            case 'SG'

                %nonconvex problem run with fixed mu

                %soglia_X_upp = sqrt(1+P/iter^p);

                %soglia_X_low = 1/soglia_X_upp;

                Hxb = Ax-b;

                Hxb_sq = Hxb.^2;

                tempx = data.ATmap(Ax./(nu^2+Hxb_sq));

                X = x./(tempx+1e-4);

                X(X<soglia_X_low) = soglia_X_low;

                X(X>soglia_X_upp) = soglia_X_upp;

                dmat = 1./X;

            case 'I'

        end

        diffx2 = diffx.*dmat;   diffg2 = diffg.*X;

    end

    bk_const = sum(dot(diffx2,diffg));  ck_const = sum(dot(diffg2,diffx));

    if (bk_const <= 0)

        alpha1 = alpha_max;
    else

        alpha1BB = norm(diffx2,'fro')^2/bk_const;

        alpha1 = min(alpha_max, max(alpha_min, alpha1BB));
    end

    if (ck_const <= 0)

        alpha2 = alpha_max;
    else

        alpha2BB = ck_const/norm(diffg2,'fro')^2;

        alpha2 = min(alpha_max, max(alpha_min, alpha2BB));
    end

    Valpha(lm) = alpha2;

    if (alpha2/alpha1<tau)

        alpha = min(Valpha);

        tau = tau*0.9;
    else
        alpha = alpha1;

        tau = tau*1.1;
    end

    Fval_list(iter) = Fval;

    iter = iter + 1;
    
    Iter_list = [Iter_list x(:)];

end

xopt = x;

end

