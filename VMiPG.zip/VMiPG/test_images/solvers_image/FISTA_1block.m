function [ybar,w1,w2,w3,dual_gap,iter] = FISTA_1block(x,v1,v2,v3,gamma,lambda,alpha,dmat,avec,data,OPTIONS,info)

if isfield(OPTIONS,'maxiter');      maxiter     = OPTIONS.maxiter;       end
if isfield(OPTIONS,'printyes');     printyes    = OPTIONS.printyes;      end
if isfield(OPTIONS,'extra_con');    extra_con   = OPTIONS.extra_con;     end

%% initialization

xk = x;

w1 = v1; w2 = v2; w3 = v3;

dobj_list = zeros(maxiter+1,1);

pobj_list = zeros(maxiter+1,1);

alp_dmat = alpha./dmat;

w1old = v1;  w2old = v2; w3old = v3;

BTv = data.Bt(v1,v2)+v3;    BTw = BTv;

y = avec - alp_dmat.*BTv;

dobj = (0.5/alpha)*sum(dot(y,dmat.*y)) ;

dobj_list(1) = dobj;

ybar = max(y+v3,0);

dybar1 = data.Bp1(ybar); dybar2 = data.Bp2(ybar); 

normybar = sqrt(dybar1.^2+dybar2.^2);

gybar = lambda*sum(normybar(:));

pobj = (1/2)*(0.5*sum(dot(ybar,dmat.*ybar)) -sum(dot(avec.*dmat,ybar)))+ gybar;

pobj_list(1) = pobj;

if printyes
    fprintf('\n      0) hsigmaplus %g psi %g gamma %g',pobj,dobj,gamma);
end

for iter = 1:maxiter
    
    w1 = v1 + gamma*data.Bp1(y);    % gamma = 1/Lip
    
    w2 = v2 + gamma*data.Bp2(y);
    
    w3 = v3 + gamma*y;
    
    R = sqrt(w1.^2 + w2.^2);
    
    I = R > lambda;
    
    w1(I) = lambda*w1(I)./R(I);
    
    w2(I) = lambda*w2(I)./R(I);
    
    w3(w3>0) = 0;
    
    BTwold = BTw;
    
    BTw = data.Bt(w1,w2) + w3;
    
  %% *************** dual objective value **************************
    
    y = avec - alp_dmat.*BTw;

    dobj = (0.5/alpha)*(dmat(:)'*y(:).^2);
    
    dobj_list(iter+1) = dobj;
    
 %% ************** to recover the primal feasibility **************
    
    ybar = max(y+v3,0);
    
    dybar1 = data.Bp1(ybar); dybar2 = data.Bp2(ybar); 
    
    normybar = sqrt(dybar1.^2+dybar2.^2);
    
    gybar = lambda*sum(normybar(:));
    
    pobj =(1/alpha)*(0.5*sum(dot(ybar,dmat.*ybar))-sum(dot(dmat.*avec,ybar)))+gybar;
    
    pobj_list(iter+1) = pobj;
    
    dual_gap = abs(pobj+dobj);
    
    if printyes
        fprintf('\n    %3g)  hsigmaplus %g psi %g dual gap %g',iter,pobj,dobj,dual_gap);
    end
    
    if (pobj+info.qks<info.gval)&&(dual_gap<=info.epsk*norm(ybar-xk,'fro')^2) 
        
        return;        
    end
    
  %% ******************* extrapolation step *********************
    
    beta = (iter-1)/(iter + extra_con);
    
    v1 = w1 + beta*(w1-w1old);
    
    v2 = w2 + beta*(w2-w2old);
    
    v3 = w3 + beta*(w3-w3old);
    
    w1old = w1; w2old = w2; w3old = w3;
    
    BTv = BTw + beta*(BTw - BTwold);
    
    y = avec - alp_dmat.*BTv;
    
end
