%% *************************************************************************
% filename: dADMM_BSN
%% **************************************************************************
%%
%% The dual ADMM armed with semismooth Newton for solving the subproblem 
%
%  min_{x,z}{0.5*||Ax||^2 -<b,x>+ g_1(Bx)+ g_2(x) 
%
%%  whose dual problem takes the following form 
%
%  min_{xi,zeta,eta}{0.5*||xi||^2 + g_1star(zeta) + wg_2star(eta)} 
%
%  s.t. b-ATmap(xi)-eta-Btzeta = 0    
%
%% where g_1star and wg_2star are respectively the conjugate of g_1 and wg_2 
%% ***************************************************************
%% 
function [xvar,xi,zeta1,zeta2,sigma,iter,resi_in, pobj, dobj]= dADMM_BSN(xi,Atxi,zeta1,zeta2,x,OPTIONS,Amap,ATmap,b,mu,info,data,lambda)
%%
if isfield(OPTIONS,'maxiter');        maxiter    = OPTIONS.maxiter;    end
if isfield(OPTIONS,'printyes');       printyes   = OPTIONS.printyes;   end
if isfield(OPTIONS,'sigma');          sigma      = OPTIONS.sigma;      end
if isfield(OPTIONS,'sigma_flag');     sigma_flag = OPTIONS.sigma_flag; end
if isfield(OPTIONS,'Bsnorm');         Bsnorm     = OPTIONS.Bsnorm;     end
if isfield(OPTIONS,'normb');          normb      = OPTIONS.normb;      end

tau = 1.618;

sig_gam = 1/Bsnorm;

if (sigma_flag)
    
    sigma_scale = 1.2;
    
    sigma_max = 1e4;
    
    sigma_min = 1e-4;
    
    prim_win = 0;  dual_win = 0;
    
end

epsk = info.epsk;

xk = x;

Btzeta = data.Bt(zeta1,zeta2);

%%
if (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n ************* ADMM for the iVMLS subproblem **************');
    fprintf('\n ****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter   SNit      pinf         dinf      ratio        sigma     time   relgap');
end
%% ********** parameters for the semismooth newton method ************

OPTIONS_SNDir.printyes = 0;

OPTIONS_SNDir.maxiter = 10;

OPTIONS_SNDir.tol = 1e-5;   % is better than min(1e-3*epsk,1e+2);

OPTIONS_SNDir.normb = normb;

%%
%% ***********************  Main Loop ***************************

tstart = clock;

for iter = 1:maxiter
    
    %% ***************** Compute xi and eta ************************
    
    tau_sig = tau*sigma;
             
    [xi,Atxi,eta,tempu,SNit] = SNCG_dADMMB(xi,Atxi,Amap,ATmap,b,OPTIONS_SNDir,sigma,mu,x,Btzeta);

   %% ********************* compute zeta ***************************
   
    zeta1 = zeta1+sig_gam*data.Bp1(tempu);
    
    zeta2 = zeta2+sig_gam*data.Bp2(tempu);
    
    Rtemp = sqrt(zeta1.^2+zeta2.^2);
    
    I = Rtemp >lambda;
    
    zeta1(I) = lambda*zeta1(I)./Rtemp(I);
    
    zeta2(I) = lambda*zeta2(I)./Rtemp(I);

  %% ********************** update x *****************************
    
    xold = x;
    
    Btzeta = data.Bt(zeta1,zeta2);
    
    x = xold + tau_sig*(b-Atxi-eta-Btzeta);
    
  %% **************************************************************
    
    pinf = norm(x-xold,'fro')/(tau_sig*(1+normb));
    
    prox_wg2 = prox_Bwg2star(x+eta,mu,1); 
    
    dinf1 = norm(xi-Amap(x),'fro')^2 + norm(eta-prox_wg2,'fro')^2;
    
    zeta_x1 = zeta1+data.Bp1(x);
    
    zeta_x2 = zeta2+data.Bp2(x);
    
    Rtemp = sqrt(zeta_x1.^2 + zeta_x2.^2);
    
    I = Rtemp > lambda; 
    
    zeta_x1(I) = lambda*zeta_x1(I)./Rtemp(I);
    
    zeta_x2(I) = lambda*zeta_x2(I)./Rtemp(I);  
   
    dinf = sqrt(dinf1 + norm(zeta1-zeta_x1,'fro')^2+norm(zeta2-zeta_x2,'fro')^2)/(1+normb);

    ratio = pinf/dinf;
    
  %% ************ checking optimality condition *******************
    
   % xvar = max(0,eta/mu);  
    
    xvar = max(0,x);
    
    dxvar1 = data.Bp1(xvar); dxvar2 = data.Bp2(xvar);
    
    tempdvec = sqrt(dxvar1.^2+dxvar2.^2);
    
    pobj = 0.5*norm(Amap(xvar),'fro')^2 - sum(dot(b,xvar)) + 0.5*mu*norm(xvar,'fro')^2 +lambda*sum(tempdvec(:));

    eta = b - Atxi - Btzeta;

    dobj = 0.5*norm(xi,'fro')^2+(0.5/mu)*norm(eta,'fro')^2-0.5*mu*norm(min(0,eta/mu),'fro')^2;
 
    resi_in = abs(dobj+pobj);

    ttime = etime(clock,tstart);
    
    
        
    if (printyes)
        
        fprintf('\n %3d    %2d      %3.2e     %3.2e     %3.2e    %3.2e   %3.2f   %3.2e',iter,SNit,pinf,dinf,ratio,sigma,ttime,resi_in);
        
    end
    
    pinf_temp = pinf*(tau_sig*(1+normb));

    Thetakyk = pobj+info.qks;

    %epsk = info.epsk;

    if (Thetakyk<=info.gval)&&(resi_in<=info.epsk*norm(xk-xvar,'fro')^2)%&&(pinf_temp <=epsk*norm(xk-xvar,'fro')^2)
        
        return;
    end
    
    %% ****************** to update the value of sigma ****************
    
    if (sigma_flag)
        
        sigma_update_iter = sigma_fun(iter);
        
        if (ratio<1)
            
            prim_win = prim_win+1;
            
        elseif (ratio>1)
            
            dual_win = dual_win+1;
            
        end
        
        if (rem(iter,sigma_update_iter)==0)
            
            if (iter<=3000)
                
                if (prim_win>max(1,1.2*dual_win))
                    
                    prim_win = 0;
                    
                    sigma = max(sigma_min,sigma/sigma_scale);
                    
                elseif (dual_win>max(1,1.2*prim_win))
                    
                    dual_win = 0;
                    
                    sigma = min(sigma_max,sigma*sigma_scale);
                end
            end
        end
    end  
end
end
function sigma_update_iter = sigma_fun(iter)
if (iter<20)
    sigma_update_iter = 3;
elseif (iter < 120)
    sigma_update_iter = 5;
elseif (iter < 250)
    sigma_update_iter = 10;
elseif (iter < 500)
    sigma_update_iter = 50;
else
    sigma_update_iter = 100;
end
end