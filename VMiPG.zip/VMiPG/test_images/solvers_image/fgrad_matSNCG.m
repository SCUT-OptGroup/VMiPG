%% ***************************************************************
%  To compute the function and gradient values of Phi_j  
%
%% ***************************************************************

function [proxu,uproxu,fval] = fgrad_matSNCG(xi,u,sigma,mu)

[proxu,uproxu,Mwg2star] = prox_Bwg2star(u,mu,1/sigma);

fval = 0.5*norm(xi,'fro')^2 + Mwg2star;  

end