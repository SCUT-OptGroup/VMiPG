%% ***************************************************************
% The conjugate_gradient method for the system of linear equations
% 
%        Ax = b    with Ax = x + gamma*AmapJ(V*AtmapJ(x))
%
% x0�� the starting point
% 
% res��the residual of Ax = b at x0, i.e., res = b- A(x0) 
%% ***************************************************************
function [x,iter,solve_ok] = cg_matdADMM(acon,Amap,ATmap,b,res,tol,maxit,nr,nc)

resnrm =zeros(maxit,1);

if ~exist('tol','var'); tol=1e-2*norm(b,'fro'); end
 
if ~exist('maxit','var'); maxit = 10; end
 
solve_ok = 1;
 
tiny = 1.0e-16;
 
stagnate_check = maxit;

d = zeros(nr,nc);   

Ad = zeros(nr,nc);

%% *************** Initialization part **************************

x = zeros(nr,nc);     % such a starting point is crucial !!!

r = res;  z=r; err = norm(r,'fro');

rho_old = err^2;  tau_old = err;  
 
theta_old = 0;

%% ******************* Main Loop ********************************

for iter = 1:maxit

    Az = acon*Amap(ATmap(z))+z;
        
    sigma = sum(dot(z,Az));

    if (abs(sigma)<tiny)   %% in this case z=0 since A is positive definite
        
        solve_ok = -1;
        
        break;        
    else
        
        alfa = rho_old/sigma;
        
        r = r - alfa*Az;    

    end
    
    norm_r = norm(r,'fro');
    
    theta = norm_r/tau_old;
    
    const = 1+theta^2;  
    
    tau = tau_old*theta/sqrt(const);
   
    gam = theta_old^2/const;
    
    eta = alfa/const;
   
    d =  gam*d + eta*z;
    
    x = x + d;
 %%--------------------- stopping conditions  ---------------------------
    
    Ad = gam*Ad + eta*Az;
    
    res = res - Ad;
    
    err = norm(res,'fro');

    if (err < tol)
       
        return; 
    end
    
    if (iter > stagnate_check) 
        
        ratio = resnrm(iter-9:iter+1)./resnrm(iter-10:iter);
        
        if (min(ratio)>0.997) && (max(ratio)<1.003)
            
            solve_ok = -1;
            
            return;
        end
    end
 %%-----------------------------------------------------------------------
    
    rho = norm_r^2;
    
    beta = rho/rho_old;
    
    z = r + beta*z;
            
    rho_old = rho;
    
    tau_old = tau;
    
    theta_old = theta; 
    
end
 
if (iter == maxit); solve_ok = -2; end
 
end    

%%%%%%%%%%%%%%%%%%%%%% End of conjugate_gradient.m  %%%%%%%%%%%%%%%%%%%%%%%   