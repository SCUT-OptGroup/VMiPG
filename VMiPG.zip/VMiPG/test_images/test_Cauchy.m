clear all

restoredefaultpath;

addpath(genpath('functions'));

addpath(genpath('cauchy'));

addpath(genpath('prob_data'));

addpath(genpath('solvers_image'));

ntest = 10;

for z = 3
    pic = z


    Fval_list1 = zeros(ntest,1); time_list1 = zeros(ntest,1); iter_list1 = zeros(ntest,1);
    dnorm_list1 = zeros(ntest,1); PSNR_list1 = zeros(ntest,1); totalin_list1 = zeros(ntest,1); totalls_list1 = zeros(ntest,1);

    Fval_list2 = zeros(ntest,1); time_list2 = zeros(ntest,1); iter_list2 = zeros(ntest,1);
    dnorm_list2 = zeros(ntest,1); PSNR_list2 = zeros(ntest,1);totalin_list2 = zeros(ntest,1);totalls_list2 = zeros(ntest,1);

    Fval_list3 = zeros(ntest,1); time_list3 = zeros(ntest,1); iter_list3 = zeros(ntest,1);
    dnorm_list3 = zeros(ntest,1); PSNR_list3 = zeros(ntest,1);totalin_list3 = zeros(ntest,1);totalls_list3 = zeros(ntest,1);

    Fval_list4 = zeros(ntest,1); time_list4 = zeros(ntest,1); iter_list4 = zeros(ntest,1);
    dnorm_list4 = zeros(ntest,1); PSNR_list4 = zeros(ntest,1);totalin_list4 = zeros(ntest,1);totalls_list4 = zeros(ntest,1);

    Fval_list5 = zeros(ntest,1); time_list5 = zeros(ntest,1); iter_list5 = zeros(ntest,1);
    dnorm_list5 = zeros(ntest,1); PSNR_list5 = zeros(ntest,1);totalin_list5 = zeros(ntest,1);totalls_list5 = zeros(ntest,1);

    Fval_list6 = zeros(ntest,1); time_list6 = zeros(ntest,1); iter_list6 = zeros(ntest,1);
    dnorm_list6 = zeros(ntest,1); PSNR_list6 = zeros(ntest,1);totalin_list6 = zeros(ntest,1);totalls_list6 = zeros(ntest,1);

    Fval_list7 = zeros(ntest,1); time_list7 = zeros(ntest,1); iter_list7 = zeros(ntest,1);
    dnorm_list7 = zeros(ntest,1); PSNR_list7 = zeros(ntest,1);totalin_list7 = zeros(ntest,1);totalls_list7 = zeros(ntest,1);

    Fval_list8 = zeros(ntest,1); time_list8 = zeros(ntest,1); iter_list8 = zeros(ntest,1);
    dnorm_list8 = zeros(ntest,1); PSNR_list8 = zeros(ntest,1);totalin_list8 = zeros(ntest,1);totalls_list8 = zeros(ntest,1);
    for nt = 1:ntest

        randn('state',double(100*nt));
        rand('state',double(100*nt));
        pic_file = ['0',num2str(pic),'.png'];
        xtrue = imread(pic_file); %2 4 5
        normalized_image = mat2gray(xtrue);
        xtrue = double(xtrue);
        [nr,nc] = size(xtrue);
        Amap = @(x) imgaussfilt(x,1,'FilterSize',9,'Padding','symmetric');
        Axtrue = Amap(normalized_image);
        gamma = 0.02;    % Cauchy para
        noise = cauchyrnd(0,gamma,[nr,nc]);
        gn = Axtrue + noise;
        min_intensity = 0;   
        max_intensity = 255;  
        obs_iVMLS = imadjust(gn, [min_intensity/255, max_intensity/255], []);

        imshow(obs_iVMLS);

        %% **************************************************************

        data.gn = gn;        % used to compuate the objective value

        data.Amap = Amap;

        data.ATmap = Amap;

        %% ************* to generate the linear mapping B ******************

        data.Bp1 = @(y)[diff(y,1,2),zeros(nr,1)];  

        data.Bp2 = @(y)[diff(y); zeros(1,nc)];    

        data.Bt = @(x1,x2)([-x1(:,1), -diff(x1(:,1:nc-1),1,2), x1(:,nc-1)] + [-x2(1,:);-diff(x2(1:nr-1,:)); x2(nr-1,:)]);

        %% ************************** VMLS_dADMM **************************

        OPTIONS.printyes = 0;

        OPTIONS.tol = 1e-4;

        OPTIONS.tol2 = 1e-6;

        x0 = max(gn,0);

        lambda = 1/0.35;

        model.nu = gamma;

        model.loss = 'Cauchy';

        method_list = {'VMiPG-H','VMiLA-H','VMiPG-S','VMiLA-S','VMiPG-bfgs','VMiLA-bfgs'} ;

        maxiter = 10000;



        for k = 1:6 %1:3 %length(method_list)

            method = method_list{k};

            switch method

                case 'VMiPG-H'

                    OPTIONS.maxiter = maxiter;

                    OPTIONS.maxiter_in = 50;

                    tstart = clock;

                    [xopt1,Fval1,dnorm1,iter1,ttime1,total_in1,total_ls1,Iter_list1] = VMiPG_SNdADMM_Cauchy(x0,data,OPTIONS,model,lambda);

                    time_list1(nt)= etime(clock,tstart);

                    Fval_list1(nt) = Fval1; iter_list1(nt)=iter1;

                    dnorm_list1(nt)= dnorm1; totalin_list1(nt) = total_in1;totalls_list1(nt) = total_ls1;

                    obs_IRPNM1 = imadjust(xopt1, [min_intensity/255, max_intensity/255], []);

                    %obs_IRPNM1 = uint8(xopt1);

                    %  figure; imshow(obs_IRPNM1);

                    psnrtemp=nr*nc;

                    PSNR_list1(nt) = 10*log10(psnrtemp/ norm(xopt1-normalized_image,'fro')^2);
                case 'VMiLA-H'

                    OPTIONS.maxiter = maxiter;

                    OPTIONS.maxiter_in = 50;

                    tstart = clock;

                    [xopt2,Fval2,dnorm2,iter2,ttime2,total_in2,total_ls2,Iter_list2] = VMiLA_SNdADMM_Cauchy(x0,data,OPTIONS,model,lambda);

                    time_list2(nt)= etime(clock,tstart);

                    Fval_list2(nt) = Fval2; iter_list2(nt)=iter2;

                    dnorm_list2(nt)= dnorm2;totalin_list2(nt) = total_in2;totalls_list2(nt) = total_ls2;

                    obs_IRPNM2 = imadjust(xopt2, [min_intensity/255, max_intensity/255], []);

                    %obs_IRPNM1 = uint8(xopt1);

                    %  figure; imshow(obs_IRPNM1);

                    psnrtemp=nr*nc;

                    PSNR_list2(nt) = 10*log10(psnrtemp/ norm(xopt2-normalized_image,'fro')^2);

                case 'VMiPG-S'

                    OPTIONS.maxiter = maxiter;

                    OPTIONS.maxiter_in = 1000;

                    OPTIONS.metric_bfgs = 0;

                    OPTIONS.metric = 'SG';

                    tstart = clock;

                    [xopt3,Fval3,dnorm3,iter3,ttime3,total_in3,total_ls3,Iter_list3] = VMiPG_FISTA_Cauchy(x0, data,OPTIONS,model,lambda);

                    time_list3(nt) = etime(clock,tstart);

                    Fval_list3(nt) = Fval3; iter_list3(nt)=iter3;

                    dnorm_list3(nt)= dnorm3;totalin_list3(nt) = total_in3;totalls_list3(nt) = total_ls3;

                    obs_IRPNM3 = imadjust(xopt3, [min_intensity/255, max_intensity/255], []);
                    %obs_IRPNM2 = uint8(xopt2);

                    %  figure; imshow(obs_IRPNM2);


                    psnrtemp=nr*nc;

                    PSNR_list3(nt) = 10*log10(psnrtemp/ norm(xopt3-normalized_image,'fro')^2);

                       case 'VMiLA-S'

                    OPTIONS.maxiter = maxiter;

                    OPTIONS.maxiter_in = 500;

                    OPTIONS.metric = 'SG';

                    OPTIONS.metric_bfgs = 0;

                    tstart = clock;

                    [xopt4,Fval4,dnorm4,iter4,ttime4,total_in4,total_ls4,Iter_list4] = VMiLA_FISTA_Cauchy(x0, data,OPTIONS,model,lambda);

                    time_list4(nt) = etime(clock,tstart);

                    Fval_list4(nt) = Fval4; iter_list4(nt)=iter4;

                    dnorm_list4(nt)= dnorm4;totalin_list4(nt) = total_in4;totalls_list4(nt) = total_ls4;

                    obs_IRPNM4 = imadjust(xopt4, [min_intensity/255, max_intensity/255], []);

                    psnrtemp=nr*nc;

                    PSNR_list4(nt) = 10*log10(psnrtemp/ norm(xopt4-normalized_image,'fro')^2);


                case 'VMiPG-bfgs'

                    OPTIONS.maxiter = maxiter;

                    OPTIONS.maxiter_in = 500;

                    OPTIONS.metric_bfgs = 1;


                    tstart = clock;

                    [xopt5,Fval5,dnorm5,iter5,ttime5,total_in5,total_ls5,Iter_list5] = VMiPG_FISTA_Cauchy(x0, data,OPTIONS,model,lambda);

                    time_list5(nt) = etime(clock,tstart);

                    Fval_list5(nt) = Fval5; iter_list5(nt)=iter5;

                    dnorm_list5(nt)= dnorm5;totalin_list5(nt) = total_in5;totalls_list5(nt) = total_ls5;

                    obs_IRPNM5 = imadjust(xopt5, [min_intensity/255, max_intensity/255], []);

                    psnrtemp=nr*nc;

                    PSNR_list5(nt) = 10*log10(psnrtemp/ norm(xopt5-normalized_image,'fro')^2);

                case 'VMiLA-bfgs'

                    OPTIONS.maxiter = maxiter;

                    OPTIONS.maxiter_in = 1000;

                    OPTIONS.metric_bfgs = 1;

                    tstart = clock;

                    [xopt6,Fval6,dnorm6,iter6,ttime6,total_in6,total_ls6,Iter_list6] = VMiLA_FISTA_Cauchy(x0, data,OPTIONS,model,lambda);

                    time_list6(nt) = etime(clock,tstart);

                    Fval_list6(nt) = Fval6; iter_list6(nt)=iter6;

                    dnorm_list6(nt)= dnorm6;totalin_list6(nt) = total_in6;totalls_list6(nt) = total_ls6;
                    
                    obs_IRPNM6 = imadjust(xopt6, [min_intensity/255, max_intensity/255], []);

                    psnrtemp=nr*nc;

                    PSNR_list6(nt) = 10*log10(psnrtemp/ norm(xopt6-normalized_image,'fro')^2);

            end

        end



    end



    fprintf('---------------------------------------------------------------------------\n');
    fprintf('   Algorithm  |  iter  |    Obj.   |    Residual   |   CPU time  \n');
    fprintf('---------------------------------------------------------------------------\n');
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e\t  %3.2f\t  %3.2f \n', 'VMiPG-H', mean(Fval_list1),mean(iter_list1), mean(time_list1), mean(PSNR_list1),mean(dnorm_list1),mean(totalin_list1),mean(totalls_list1));
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e\t  %3.2f\t  %3.2f \n', 'VMiLA-H', mean(Fval_list2),mean(iter_list2), mean(time_list2), mean(PSNR_list2),mean(dnorm_list2),mean(totalin_list2),mean(totalls_list2));
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e\t  %3.2f\t  %3.2f \n', 'VMiPG-S', mean(Fval_list3),mean(iter_list3), mean(time_list3), mean(PSNR_list3),mean(dnorm_list3),mean(totalin_list3),mean(totalls_list3));
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e\t  %3.2f\t  %3.2f \n', 'VMILA-S', mean(Fval_list4),mean(iter_list4), mean(time_list4), mean(PSNR_list4),mean(dnorm_list4),mean(totalin_list4),mean(totalls_list4));
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e\t  %3.2f\t  %3.2f \n', 'VMIPG-bfgs', mean(Fval_list5),mean(iter_list5), mean(time_list5), mean(PSNR_list5),mean(dnorm_list5),mean(totalin_list5),mean(totalls_list5));
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e\t  %3.2f\t  %3.2f \n', 'VMILA-bfgs', mean(Fval_list6),mean(iter_list6), mean(time_list6), mean(PSNR_list6),mean(dnorm_list6),mean(totalin_list6),mean(totalls_list6));

end