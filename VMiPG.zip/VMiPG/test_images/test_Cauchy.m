clear all

restoredefaultpath;

addpath(genpath('VMILA'));
addpath(genpath('functions'));

addpath(genpath('cauchy'));

addpath(genpath('prob_data'));

addpath(genpath('solvers_image'));

ntest = 10;

for z = 1:7
    pic=z
    
    Fval_list1 = zeros(ntest,1); time_list1 = zeros(ntest,1); iter_list1 = zeros(ntest,1);
    dnorm_list1 = zeros(ntest,1); PSNR_list1 = zeros(ntest,1);
    
    Fval_list2 = zeros(ntest,1); time_list2 = zeros(ntest,1); iter_list2 = zeros(ntest,1);
    dnorm_list2 = zeros(ntest,1); PSNR_list2 = zeros(ntest,1);
    
    Fval_list3 = zeros(ntest,1); time_list3 = zeros(ntest,1); iter_list3 = zeros(ntest,1);
    dnorm_list3 = zeros(ntest,1); PSNR_list3 = zeros(ntest,1);

    
    for nt = 1:ntest
        
        randn('state',double(100*nt));
        rand('state',double(100*nt));
        pic_file = ['0',num2str(pic),'.png'];
        xtrue = imread(pic_file); %2 4 5
        normalized_image = mat2gray(xtrue);
        xtrue = double(xtrue);
        [nr,nc] = size(xtrue);
        Amap = @(x) imgaussfilt(x,1,'FilterSize',9,'Padding','symmetric');
        Axtrue = Amap(normalized_image);
        gamma = 0.02;    % Cauchy分布的尺度参数
        noise = cauchyrnd(0,gamma,[nr,nc]);
        gn = Axtrue + noise;
        min_intensity = 0;    % 原始数据最小强度
        max_intensity = 255;  % 原始数据最大强度
        % 还原归一化图像
        obs_iVMLS = imadjust(gn, [min_intensity/255, max_intensity/255], []);

        imshow(obs_iVMLS);
        
        %% **************************************************************
        
        data.gn = gn;        % used to compuate the objective value
        
        data.Amap = Amap;
        
        data.ATmap = Amap;
        
        %% ************* to generate the linear mapping B ******************
        
        data.Bp1 = @(y)[diff(y,1,2),zeros(nr,1)];  %相邻两列差分
        
        data.Bp2 = @(y)[diff(y); zeros(1,nc)];     %相邻两行差分
        
        data.Bt = @(x1,x2)([-x1(:,1), -diff(x1(:,1:nc-1),1,2), x1(:,nc-1)] + [-x2(1,:);-diff(x2(1:nr-1,:)); x2(nr-1,:)]);
        
        %% ************************** VMLS_dADMM **************************
        
        OPTIONS.printyes = 1;
        
        OPTIONS.tol = 1e-4;
        
        x0 = max(gn,0);
        
        lambda = 1/0.35;
        
        model.nu = gamma;
        
        model.loss = 'Cauchy';
        
        method_list = {'VMiPG-H','VMiPG-S','VMILA-S','VMiPG-H1'} ;
        
        for k = 1:3 %1:3 %length(method_list)
            
            method = method_list{k};
            
            switch method
                
                case 'VMiPG-H'
                    
                    OPTIONS.maxiter = 2000;
                    
                    OPTIONS.maxiter_in = 50;
                    
                    tstart = clock;
                    
                    [xopt1,Fval1,dnorm1,iter1] = VMiPG_SNdADMM_Cauchy(x0,data,OPTIONS,model,lambda);
                    
                    time_list1(nt)= etime(clock,tstart);
                    
                    Fval_list1(nt) = Fval1; iter_list1(nt)=iter1;
                    
                    dnorm_list1(nt)= dnorm1;
                    
                    % 还原归一化图像
                    obs_IRPNM1 = imadjust(xopt1, [min_intensity/255, max_intensity/255], []);
                    
                    %obs_IRPNM1 = uint8(xopt1);
                    
                  %  figure; imshow(obs_IRPNM1);
                    
                    psnrtemp=nr*nc;
                    
                    PSNR_list1(nt) = 10*log10(psnrtemp/ norm(xopt1-normalized_image,'fro')^2);
                    
                case 'VMiPG-S'
                    
                    OPTIONS.maxiter = 10000;
                    
                    OPTIONS.maxiter_in = 1500;
                    
                    OPTIONS.metric = 'SG';
                    
                    tstart = clock;
                    
                    [xopt2,Fval2,dnorm2,iter2] = VMiPG_FISTA_Cauchy(x0, data,OPTIONS,model,lambda);
                    
                    time_list2(nt) = etime(clock,tstart);
                    
                    Fval_list2(nt) = Fval2; iter_list2(nt)=iter2;
                    
                    dnorm_list2(nt)= dnorm2;
                    
                    % 还原归一化图像
                    obs_IRPNM2 = imadjust(xopt2, [min_intensity/255, max_intensity/255], []);
                    %obs_IRPNM2 = uint8(xopt2);
                    
                  %  figure; imshow(obs_IRPNM2);
                    
                   
                    psnrtemp=nr*nc;
                    
                    PSNR_list2(nt) = 10*log10(psnrtemp/ norm(xopt2-normalized_image,'fro')^2);
                case 'VMILA-S'
                    
                    NIT=10000;
                    verbose=1;
                    alpha_min=1e-5;  alpha_max=100;
                    inn_ini=1;
                    eta = 1e-6;
                    P=1e10;  p=2;
                    benchsol={0,xtrue};
                    
                    OPTIONS.metric='SG';
                    
                    tstart = clock;
                    
                    [xopt3,Fval3,dnorm3,iter3] = VMILA_Cauchy(gn, data.Amap, data.ATmap,lambda,data.Bp1, data.Bp2, ...
                        data.Bt, NIT, verbose, benchsol, eta, P, p, alpha_min, alpha_max, inn_ini,OPTIONS);
                    
                    time_list3(nt) = etime(clock,tstart);
                    
                    Fval_list3(nt) = Fval3(end); iter_list3(nt)=length(Fval3);
                    
                    dnorm_list3(nt)= dnorm3(end);
                    
                    % 还原归一化图像
                    obs_IRPNM3 = imadjust(xopt3, [min_intensity/255, max_intensity/255], []);
                    
                    %obs_IRPNM3 = uint8(xopt3);
                    
                   % figure; imshow(obs_IRPNM3);
                    
                   psnrtemp=nr*nc;
                    
                    PSNR_list3(nt) = 10*log10(psnrtemp/ norm(xopt3-normalized_image,'fro')^2);
                    
            end
            
        end
        
        
        
    end
    
    
    fprintf('---------------------------------------------------------------------------\n');
    fprintf('   Algorithm  |  iter  |    Obj.   |    Residual   |   CPU time  \n');
    fprintf('---------------------------------------------------------------------------\n');
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e \n', 'VMiPG-H', mean(Fval_list1),mean(iter_list1), mean(time_list1), mean(PSNR_list1),mean(dnorm_list1));
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e \n', 'VMiPG-S', mean(Fval_list2),mean(iter_list2), mean(time_list2), mean(PSNR_list2),mean(dnorm_list2));
    fprintf('%12s: \t %3.2f \t  %3.4f \t  %3.2f \t  %3.2f\t  %3.2e \n', 'VMILA-S', mean(Fval_list3),mean(iter_list3), mean(time_list3), mean(PSNR_list3),mean(dnorm_list3));

    folder = 'image_result';
    
    filename = ['0',num2str(pic),'image'];% 01=02
    
    filepath = fullfile(pwd,folder,filename);
    
end