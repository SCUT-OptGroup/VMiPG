function [fval,grad,dd] = Loss_2block(Ax,b,data,model)

nu = model.nu;

switch model.loss
    
    case 'Cauchy'
        Axb = Ax-b;
        
        Axb_sq = Axb.^2;
        
        fval = 0.5*sum(sum(log(nu^2+Axb_sq)));
        
        if nargout >=3
            
            temp_Axb = nu^2+Axb_sq;
            
            grad = data.ATmap(Axb./temp_Axb);
            
            dd = (nu^2-Axb_sq)./temp_Axb.^2;
            
        elseif nargout>=2
            
            grad = data.ATmap(Axb./(nu^2+Axb_sq));
        end
        
    case 'Student'
        
        Axb = Ax-b;
        
        Axb_sq = Axb.^2;
        
        fval = 0.5*sum(sum(log(1+Axb_sq/nu)));
        
        if nargout >=3
            
            grad = data.ATmap(Axb./(nu+Axb_sq));
            
            dd = (nu-Axb_sq)./(nu+Axb_sq).^2;
            
        elseif nargout>=2
            
            grad = data.ATmap(Axb./(nu+Axb_sq));
        end
end