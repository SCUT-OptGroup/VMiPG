%% **********************************************************************
%  filename: prox_g1star
%% **********************************************************************
%  to compute the proximal mapping of prox_{(1/gamma)g_1star}(z)
%
%% Case 1: g_1(x) = lambda*||Bx||_1 with orthogonal B
%
%           g_1star(z)= 0 if ||Bz||_inf<=lambda, otherwise +infty
%% 

function proxz = prox_g1star(z,data,lambda,gamma)

%lambda = model.lambda;

tempu = max(min(data.Bmap(z),lambda),-lambda);

proxz = data.BTmap(tempu);