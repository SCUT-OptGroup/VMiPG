%************************************************************************
% filename: bfgsBx
%************************************************************************
%% to compute Bx, which is exactly Gk(x) in our paper
%%
function Bx = bfgsBx_matrix(x,s,y)

tau = sum(dot(s,y))/norm(y,'fro')^2;

sqynorm = norm(y,'fro')^2; sqsnorm = norm(s,'fro')^2;

Bx = x - (sum(dot(s,x))/sqsnorm)*s + (sum(dot(y,x))/sqynorm)*y;

Bx = Bx/tau;