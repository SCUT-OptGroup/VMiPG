%************************************************************************
% filename: bfgsHx
%************************************************************************
%% to compute Hx, which is exactly Gk^{-1}(x) in our paper
%%
function Hx = bfgsHx_matrix(x,s,y)

rho = 1/sum(dot(s,y));

tau = sum(dot(s,y))/norm(y,'fro')^2;

u = s-0.5*tau*y;

Hx = tau*x +2*rho*sum(dot(u,x))*u-rho*0.5*tau^2*sum(dot(y,x))*y;