%% ****************************************************************
%   filename: prox_Bwg2star
%% ****************************************************************
% Case 1: wg2(x) = delta_{[0,inf]}(x)+0.5*mu*||x||^2
%         wg2star is the conjugate function of wg2
%         to compute the proximal mapping and the moreal envelope of wg2star 

function [projz,zprojz,Mwg2star]= prox_Bwg2star(z,mu,gamma)

gam_mu = gamma+mu;

tempz = z/gam_mu;

zprojz = gamma*max(0,tempz);

projz = z-zprojz;

if nargout>=2
  
   Mwg2star = 0.5*gam_mu*norm(min(0,tempz),'fro')^2+(0.5/gam_mu)*norm(z,'fro')^2;
   
end   
end