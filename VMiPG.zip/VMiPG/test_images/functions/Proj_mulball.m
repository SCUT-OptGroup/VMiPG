%% *************************************************************************
%  filename: Proj_mulball 
%
%% ************************************************************************
%% This code is to solve the following simple convex optimization 
%  
%  Y = argmin{0.5*||X-G||_F^2  s.t. ||X_i||<=lambda, i=1,2,...,m}
%  
%  where Xi is the ith column of the matrix X.  
%
%   Y_i* = min(1,lambda/||G_i||)G_i
%
%
%% *************************************************************************
% Copyright by Taoting and Shaohua Pan, 2018.3.19

function ProxG = Proj_mulball(G,lambda)

Gcnorm = dot(G,G).^(1/2);

ProxG = G.*min(1,lambda./Gcnorm);

    


