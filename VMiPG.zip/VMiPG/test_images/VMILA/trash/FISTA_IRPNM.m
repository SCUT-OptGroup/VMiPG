function [ybar,w1,w2,w3,hsigmaplus,G,iter,g1ybar,g2ybar,normgybar,varargout] = FISTA_IRPNM(v1,v2,v3,...
                                                               gamma,beta,alpha,X,D,grad1,grad2,div,z,f1k,g,NIT,eta,a,varargin)
% D is the variable matrix.
psivec = zeros(NIT+1,1);
hsigmavec = zeros(NIT+1,1);
if nargin == 18
    verbose = varargin{1};
else
    verbose = 2;
end
hsigmafixedpart = -f1k -alpha/2*(X(:)'*(g(:).^2));
Psifixedpart    = hsigmafixedpart + (D(:)'*(z(:).^2))/2/alpha;
alphaX = alpha*X;
w1old = v1; w2old = v2; w3old = v3;
ATv = div(v1,v2)+v3; ATw = ATv;
y   = z - alphaX.*ATv;
gstarv = 0;
Psi = -(D(:)'*(y(:).^2))/2/alpha - gstarv + Psifixedpart; %dual problem
psivec(1) = -Psi;
g1y = grad1(y); g2y = grad2(y); 

ybar   = max(y,0);
g1ybar = grad1(ybar); g2ybar = grad2(ybar); normgybar = sqrt(g1ybar.^2+g2ybar.^2);
f1ybar = beta*sum(normgybar(:));
hsigmaplus = (D(:)'*(ybar(:)-z(:)).^2)/2/alpha + f1ybar + hsigmafixedpart;
hsigmavec(1) = hsigmaplus;
if verbose
    fprintf('\n      0) hsigmaplus %g psi %g gamma %g',hsigmaplus,Psi,gamma);
end

for iter = 1:NIT
    w1 = v1 + gamma*g1y;
    w2 = v2 + gamma*g2y;
    w3 = v3 + gamma*y;
    
    R = sqrt(w1.^2 + w2.^2);
    I = R > beta;
    %% calculate the projection to B(0,beta) X B(0,beta) X R<=0
    w1(I) = beta*w1(I)./R(I);% project to B(0,beta).
    w2(I) = beta*w2(I)./R(I);
    w3(w3 > 0) = 0;
    
    ATwold = ATw;
    ATw = div(w1,w2) + w3;
    
    y   = z - alphaX.*ATw; %z^k-alphak D_k^{-1}A^T v ?
    gstarv = 0;
    Psi    = -(D(:)'*y(:).^2)/2/alpha - gstarv + Psifixedpart;
    psivec(iter+1) = -Psi;
    ybar   = max(y,0);
    g1ybar = grad1(ybar); g2ybar = grad2(ybar); normgybar = sqrt(g1ybar.^2+g2ybar.^2);
    f1ybar = beta*sum(normgybar(:));
    hsigmaplus = (D(:)'*(ybar(:)-z(:)).^2)/2/alpha + f1ybar + hsigmafixedpart;
    hsigmavec(iter+1) = hsigmaplus;
    if verbose,
        fprintf('\n    %3g)  hsigmaplus %g psi %g',iter,hsigmaplus,Psi);
    end
    if hsigmaplus <= eta*Psi
        break;
    end

    %extrapolation step
    alphan = (iter -1)/(iter + a);
    v1 = w1 + alphan*(w1-w1old);
    v2 = w2 + alphan*(w2-w2old);
    v3 = w3 + alphan*(w3-w3old);
    w1old = w1; w2old = w2; w3old = w3;
    
    ATv    = ATw + alphan*(ATw - ATwold);%div(v1,v2)+ v3;
    y      = z - alphaX.*ATv;
    g1y    = grad1(y); g2y = grad2(y); 
    
end
G = hsigmaplus - Psi;
if nargout >= 11 
   psivec(iter +2:end) = [];
   hsigmavec(iter+2:end) = [];
   varargout{1}.psi = psivec; varargout{1}.hsigma = hsigmavec; 
end