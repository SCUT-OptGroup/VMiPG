*****************
* VMILA package *
*****************

This software implements the Variable Metric Inexact Line�search Algorithm (VMILA) described in the paper 

S. Bonettini, I. Loris, F. Porta, M. Prato, Variable metric inexact line-search based methods for nonsmooth optimization

currently submitted for publication and available at the website http://arxiv.org/abs/1506.00385

The VMILA package includes four .m and three .mat files, which allow to reproduce the VMILA plots in the numerical experiments described in Section 6.1 of the paper.

In particular:

1. main.m is the script with the choice of the dataset and the call to VMILA

2. VMILA.m is the function implementing VMILA

3. FISTA.m is the function implementing the Fast Iterative Shrinkage-Thresholding algorithm by Beck and Teboulle (SIAM J Imagin Sci 2 (2009), 183-202), which is used as inner solver in VMILA

4. dctshift.m is a function creating an array containing the first column of a blurring matrix when implementing reflexive boundary conditions (see Chapter 4 of P.C. Hansen, J.G. Nagy, D.P. O'Leary, Deblurring Images - Matrices, Spectra, and Filtering, SIAM, Philadelphia, 2006).

As for the .mat files,

1. TP_cameraman_RBC is the dataset based on the 256x256 Matlab cameraman image

2. TP_fantoccio_RBC is the dataset based on the 256x256 Matlab Shepp-Logan phantom

3. TP_micro_RBC is the dataset based on a 128x128 confocal microscopy phantom (see also R.M. Willet and R.D. Nowak, IEEE Trans. Med. Imaging 22 (2003), 332�350)

The software is a beta version and further optimizations and documentation are still in progress.

For comments and further information please send us an email at silvia.bonettini@unife.it.