clear all
close all

%problem = 'TP_cameraman_RBC.mat'; 
%problem = 'TP_micro_RBC.mat';
problem = 'TP_fantoccio_RBC.mat';

info = load(problem);
scelta   = info.type; 
boundary = info.boundary;
beta     = info.beta; 
delta    = info.delta;
xopt     = info.xopt;
gn       = info.gn;
obj      = info.obj;
bg       = info.bg;
psf = info.psf;

err_min  = ~isempty(xopt);

zeroindex = gn <= 0;
nonzeroindex = ~zeroindex;

center = info.center;
e1   = zeros(size(psf)); e1(1,1) = 1;
eigA = dct2(dctshift(psf,center))./dct2(e1);
H    =  @(x)idct2( eigA .* dct2(x) );
HT   =  @(x)idct2( eigA .* dct2(x) );
x0 = gn;

n = length(gn); 
z      = zeros(n,1); zt = zeros(1,n);
grad1  = @(y)[diff(y,1,2), z]; %�������в��
grad2  = @(y)[diff(y); zt]; %�������в��
div    = @(x1,x2)([-x1(:,1), -diff(x1(:,1:n-1),1,2), x1(:,n-1)] + [-x2(1,:);-diff(x2(1:n-1,:)); x2(n-1,:)]);

if err_min
    benchsol = {obj,xopt};
    xstar   = benchsol{2};
    dx1     = grad1(xopt);
    dx2     = grad2(xopt);
    gu_norm = sqrt(dx1.^2+dx2.^2+delta^2); % Total Variation
    
    den                = H(xopt) + bg;
    rapp               = zeros(size(gn));
    rapp(nonzeroindex) = gn(nonzeroindex)./ den(nonzeroindex); %  gn = b; den = x
    
    KL    = sum( gn(nonzeroindex).* log(rapp(nonzeroindex)) + den(nonzeroindex) - gn(nonzeroindex) );
    KL    = KL + sum(den(zeroindex)); % Kullback-Leibler   
    fstar = beta*sum(sum(gu_norm)) + KL;
else
    benchsol = {obj};
end

NIT = 500; tol = 1e-16;
verbose = 1;
fprintf('\n\n');
P = 1e10; p = 2;
alpha_min = 1e-5; alpha_max = 1e2;
inn_ini  = 1;
eta = 1e-6;
[xSGP,TimeCostSGP,PrimalSGP] = VMILA(x0, H, HT, bg, beta, grad1, grad2, ...
                                     div, NIT, verbose, benchsol, eta, P, p, alpha_min, alpha_max, inn_ini);
if err_min
   figure(1), semilogy((PrimalSGP - fstar)/fstar,'k'); legend(['VMILA, \eta = ' num2str(eta)]);
   set(gca,'yscale','log'); xlabel('k'); ylabel('$|f(x^{(k)})-f^*|/f^*$','Interpreter','Latex');
   figure(2), semilogy(TimeCostSGP,(PrimalSGP - fstar)/fstar,'k'); legend(['VMILA, \eta = ' num2str(eta)]);
   set(gca,'yscale','log'); xlabel('time(s)'); ylabel('$|f(x^{(k)})-f^*|/f^*$','Interpreter','Latex');
end