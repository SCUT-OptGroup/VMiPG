function [Iter_mat,x,Primal,dnorm,itr,TimeCost,alpha_vec,err,nit_vec,hsigma_vec,G_vec] = ...
    VMILA_Cauchy(gn, H, HT, rho, grad1, grad2, div, NIT, verbose, obj,eta,P,p,alpha_min,alpha_max,inn_ini,OPTIONS)

tol = OPTIONS.tol;
metric = OPTIONS.metric;
nobj = length(obj);
for i = 1 : nobj
    normobj(i) = norm(obj{i}(:));
    err{i}     = zeros(NIT+1,1); %arrays to store errors per iteration
end
gamma1 = 0.02;
%Primal     = zeros(NIT+1,1);
alpha_vec  = zeros(NIT+1,1);
nit_vec    = zeros(NIT+1,1);
%TimeCost   = zeros(NIT+1,1);
hsigma_vec = zeros(NIT+1,1);
G_vec      = zeros(NIT+1,1);

n = length(gn);

gamma = 1e-4;  % linesearch parameters
beta = 0.4;

Malpha = 3;    % memory on alphaBB
tau = 0.5;
Valpha = 1e30 * ones(Malpha,1);

soglia_X_low = 1e-10;
soglia_X_upp = 1e+10;  % threshold on scaling matrix
alpha = 1.3;           % initial alpha

% initial point
x = max(gn,0);

% gradient and objective function at current x
dx1     = grad1(x);
dx2     = grad2(x);
densq   = sqrt(dx1.^2 + dx2.^2);
TV      = sum(densq(:));
%den     = H(x) + bg;
%rapp(nonzeroindex) = gn(nonzeroindex)./ den(nonzeroindex); %den=xi gn=bi
%KL = sum( gn(nonzeroindex).* log(rapp(nonzeroindex)) + den(nonzeroindex) - gn(nonzeroindex) );
%KL = KL + sum(den(zeroindex));
%fv = KL + rho*TV; % objective function

Hx = H(x);

den = Hx-gn;

fval = 0.5*sum(sum(log(gamma1^2+(den.^2))));

fv = fval + rho*TV;

Hxb_sq = den.^2;

grad = HT(den./(gamma1^2+Hxb_sq));
%g_KL = HTe - HT(rapp);
%g = g_KL; % gradient
g = grad;
Primal(1) = fv;
alpha_vec(1) = alpha;
for i = 1 : nobj
    err{i}(1) = norm(obj{i}(:)-x(:))/normobj(i);
end

if 0%verbose
    
    fprintf('\nInitial: Primal=%8.3e', Primal(1));
    
    for i=1:nobj
        fprintf(' err{%g} %g', i, err{i}(1));
    end
end

% start CPU clock
TimeCost(1)=0;
Iter_mat=[];
Iter_mat=[Iter_mat x(:)];
t0 = tic;

% step 1 - scaling matrix
%X =  ones(n);
%X(X < soglia_X_low) = soglia_X_low;
%X(X > soglia_X_upp) = soglia_X_upp;
%D = 1./X;

switch metric
    
    case 'SG'
        
        Hxb = den;
        
        Hxb_sq = Hxb.^2;
        
        tempx = HT(Hx./(gamma1^2+Hxb_sq));
        
        X = x./(tempx+1e-4);
        
        X(X<soglia_X_low) = soglia_X_low;
        
        X(X>soglia_X_upp) = soglia_X_upp;
        
        D = 1./X;
        
    case 'I'
        X = ones(n);
        
        D = 1./X;
end

for itr = 1:NIT
    
    Valpha(1:Malpha-1) = Valpha(2:Malpha);
    
    % step 2 - compute ytilde
    z = x - alpha*X.*grad;
    if itr == 1 || inn_ini == 0
        v10 = zeros(size(x)); v20 = v10; v30 = v10;
    else
        v10 = v1; v20 = v2; v30 = v3;
    end
    inNIT = 1500;
    a = 2.1;
    gamma_inn = 1/(9*max(X(:)))/alpha;
    [y,v1,v2,v3,hsigma,G,nit,dy1,dy2] = FISTA(v10,v20,v30,gamma_inn,rho,...
        alpha,X,D,grad1,grad2,div,z,rho*TV,grad,inNIT,eta,a,max(0,verbose-1));
    hsigma_vec(itr) = hsigma;
    G_vec(itr) = G;
    nit_vec(itr) = nit;
    
    % step 3 - compute d
    d = y - x;
    
    dnorm = norm(d);
    
    if dnorm <= tol
       %return
    end
    gd = hsigma;
    denold = den;
    dx1old = dx1; dx2old = dx2;
    lam = 1;
    Hd  = H(d);
    A1d = dy1 - dx1;
    A2d = dy2 - dx2;
    
    % step 4 - linesearch
    fcontinue = 1;
    
    fr = fv;
    
    while fcontinue
        
        xplus = x + lam*d;
        
        % update the objective function value
        dx1     = dx1old + lam*A1d;
        dx2     = dx2old + lam*A2d;
        densq   = sqrt(dx1.^2 + dx2.^2);
        TV      = sum(densq(:));
        den     = denold + lam*Hd;

        fval = 0.5*sum(sum(log(gamma1^2+(den.^2))));
        
        fv = fval + rho*TV;
        
        % Armijo condition
        if ( fv <= fr + gamma * lam * gd || lam<1e-12)
            Hxb_sq = den.^2;
            grad = HT(den./(gamma1^2+Hxb_sq));
            x = xplus; clear xplus;
            sk = lam*d; % difference between iterates
            %g_KL    = HTe - HT(rapp);
            gtemp   = grad ;
            yk = gtemp - g; % difference between gradients
            g = gtemp; clear gtemp;
            fcontinue = 0;
        else
            lam = lam * beta;
        end
    end
    
    for i=1:nobj
        err{i}(itr + 1) = norm(obj{i}(:)-x(:))/normobj(i);
    end
    if 0%verbose
        fprintf('\n%4d): f(x)=%5.3f  alpha %g nit %g', itr, ...
            fv, alpha, nit );
        for i=1:nobj
            fprintf(' err{%g} %g', i, err{i}(itr + 1));
        end
    end
    

    switch metric
        
        case 'SG'
            
           soglia_X_upp = sqrt(1 + P/itr^p);
            
           soglia_X_low = 1/soglia_X_upp;
            
           Hxb = den;
            
           Hxb_sq = Hxb.^2;
            
           Hx = den+gn;
            
           tempx = HT(Hx./(gamma1^2+Hxb_sq));
            
            X = x./(tempx+1e-4);
            
            X(X < soglia_X_low) = soglia_X_low;
            
            X(X > soglia_X_upp) = soglia_X_upp;
            
            D = 1./X;
            
        case 'I'
            X = ones(n,n);

            D = 1./X;
    end
    
    sk2 = sk.*D;  yk2 = yk.*X;
    
    bk = sum(dot(sk2,yk));  ck = sum(dot(yk2,sk));
    if (bk <= 0)
        alpha1 = alpha_max;
    else
        alpha1BB = sum(dot(sk2,sk2))/bk;
        alpha1 = min(alpha_max, max(alpha_min, alpha1BB));
    end
    if (ck <= 0)
        alpha2 = alpha_max;
    else
        alpha2BB = ck/sum(dot(yk2,yk2));
        alpha2 = min(alpha_max, max(alpha_min, alpha2BB));
    end
    
    Valpha(Malpha) = alpha2;
    
    if (alpha2/alpha1 < tau)
        alpha = min(Valpha);
        tau = tau*0.9;
    else
        alpha = alpha1;
        tau = tau*1.1;
    end
        if(itr>10)&&(max(abs(fv-Primal(itr-10:itr-1)))<=1.0e-8*max(1,abs(fv)))                
      %  return;
    end
    Primal(itr + 1)   = fv;
    TimeCost(itr + 1) = toc(t0);
    alpha_vec(itr + 1) = alpha;
    
    Iter_mat=[Iter_mat x(:)];
    
end

Primal(itr+2:end) = [];
nit_vec(itr+1) = [];
hsigma_vec(itr+1) = [];
G_vec(itr+1) = [];
alpha_vec(itr+2:end) = [];
TimeCost(itr+2:end) = [];
if 0%verbose
    fprintf('\n');
end